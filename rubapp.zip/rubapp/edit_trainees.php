<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{

if(isset($_GET['edit']))
	{
		$editid=$_GET['edit'];
	}


	
if(isset($_POST['submit']))
  {
	
	$idedit=$_POST['idedit'];
	$firstname=$_POST['firstname'];
	$lastname=$_POST['lastname'];
	$branch=$_POST['branch'];
	$nid=$_POST['nid'];
	$phone=$_POST['phone'];
	$status=$_POST['status'];
	$education=$_POST['education'];
	$vstatus=$_POST['vstatus'];
	$regdate=$_POST['regdate'];
	$gradate=$_POST['gradate'];
	$birthdate=$_POST['birthdate'];
	$gender=$_POST['gender'];
	$province=$_POST['province'];
	$district=$_POST['district'];
	$sector=$_POST['sector'];
	$ubudehe=$_POST['ubudehe'];
	$kit=$_POST['kit'];

	$sql="UPDATE trainees set  firstname=(:firstname), lastname=(:lastname),branch=(:branch),nid=(:nid),edu_level=(:education),
	 visual_status=(:vstatus),gender=(:gender),gradate=(:gradate),regdate=(:regdate),m_status=(:status),phone=(:phone),
	   province=(:province),district=(:district),sector=(:sector),ubudehe=(:ubudehe),birthdate=(:birthdate),kit=(:kit) where id=(:idedit)";
	$query = $dbh->prepare($sql);
	$query-> bindParam(':idedit', $idedit, PDO::PARAM_STR);
	$query-> bindParam(':firstname', $firstname, PDO::PARAM_STR);
	$query-> bindParam(':lastname', $lastname, PDO::PARAM_STR);
	$query-> bindParam(':branch', $branch, PDO::PARAM_STR);
	$query-> bindParam(':nid', $nid, PDO::PARAM_STR);
	$query-> bindParam(':education', $education, PDO::PARAM_STR);
	$query-> bindParam(':vstatus', $vstatus, PDO::PARAM_STR);
	$query-> bindParam(':birthdate', $birthdate, PDO::PARAM_STR);
	$query-> bindParam(':regdate', $regdate, PDO::PARAM_STR);
	$query-> bindParam(':gradate', $gradate, PDO::PARAM_STR);
	$query-> bindParam(':gender', $gender, PDO::PARAM_STR);
	$query-> bindParam(':province', $province, PDO::PARAM_STR);
	$query-> bindParam(':district', $district, PDO::PARAM_STR);
	$query-> bindParam(':sector', $sector, PDO::PARAM_STR);
	$query-> bindParam(':ubudehe', $ubudehe, PDO::PARAM_STR);
	$query-> bindParam(':kit', $kit,PDO::PARAM_STR);
	$query-> bindParam(':status', $status,PDO::PARAM_STR);
	$query-> bindParam(':phone', $phone,PDO::PARAM_STR);
	$query->execute();
	$msg="Information Updated Successfully";
	
}    
?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>Edit User</title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">

	<script type= "text/javascript" src="../vendor/countries.js"></script>
	<style>
.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
	background: #dd3d36;
	color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
	background: #5cb85c;
	color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.error{
	color:red;
}
		</style>
</head>

<body>
<?php
		$sql = "SELECT * from trainees where id = :editid";
		$query = $dbh -> prepare($sql);
		$query->bindParam(':editid',$editid,PDO::PARAM_INT);
		$query->execute();
		$result=$query->fetch(PDO::FETCH_OBJ);
		$cnt=1;	
?>
	<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<h4 class="page-title">Edit trainee : <?php echo htmlentities($result->firstname)?>
						<?php echo htmlentities($result->lastname); ?></h4>
						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-primary">
									<div class="panel-heading">Edit Trainnee information
									<div class="text-right">				
  <a href="mrcb_trainees.php" class="text-success mb-2" >BACK</a>
</div>
									</div>
<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap"><strong><?php echo htmlentities($result->firstname);?>'s</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>

									<div class="panel-body">
<form method="post" class="form-horizontal" enctype="multipart/form-data" id="newModalForm" name="imgform">
<div class="form-group">
<label class="col-sm-2 control-label">First name<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="firstname" class="form-control" required value="<?php echo htmlentities($result->firstname);?>">
</div>
<label class="col-sm-2 control-label">Last name<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="lastname" class="form-control" required value="<?php echo htmlentities($result->lastname);?>">
</div>
</div>
<div class="form-group">

<label class="col-sm-2 control-label">National ID<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="nid" class="form-control" required value="<?php echo htmlentities($result->nid);?>">
</div>
<label class="col-sm-2 control-label">Ubudehe<span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="ubudehe" class="form-control" >
                            <option  value="<?php echo htmlentities($result->ubudehe);?>"><?php echo htmlentities($result->ubudehe);?></option>
                            <option value="A">A</option>
                            <option value="B">B</option>
                             <option value="C">C</option>
                             <option value="D">D</option>
                             <option value="E">E</option>
                            </select>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Education level<span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="education" class="form-control" >
                            <option value="<?php echo htmlentities($result->edu_level);?>"> change your education :"<?php echo htmlentities($result->edu_level);?>"</option>
                            <option value="primary">primary</option>
                            <option value="secondary">secondary</option>
                            <option value="University">University</option>
                            <option value="Masters">Masters</option>
                            <option value="phd">Phd</option>
                            <option value="none">None</option>
                            </select>
</div>
<label class="col-sm-2 control-label">Visual Status<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="vstatus" class="form-control" required value="<?php echo htmlentities($result->visual_status);?>">
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">REGISTRATION DATE <span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="regdate" class="form-control" required value="<?php echo htmlentities($result->regdate);?>">
</div>
<label class="col-sm-2 control-label">GRADUATION DATE<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="gradate" class="form-control" required value="<?php echo htmlentities($result->gradate);?>">
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">BIRTH DATE<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="date" name="birthdate" class="form-control" required value="<?php echo htmlentities($result->birthdate);?>">
</div>
<label class="col-sm-2 control-label">Marital Status<span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="status" class="form-control" >
                            <option value="<?php echo htmlentities($result->m_status);?>">select to change your status :"<?php echo htmlentities($result->m_status);?>"</option>
							<option value="single">single</option>
                             <option value="married">married</option>
                              <option value="divorced">Divorced</option>
                               <option value="widowed">Widowed</option>
                            </select>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Gender<span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="gender" class="form-control" >
                            <option  value="<?php echo htmlentities($result->gender);?>"><?php echo htmlentities($result->gender);?></option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            </select>
</div>
<label class="col-sm-2 control-label">Province<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="province" class="form-control" required value="<?php echo htmlentities($result->province);?>">
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">District<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="district" class="form-control" value="<?php echo htmlentities($result->district);?>">
</div>
<label class="col-sm-2 control-label">Sector<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="sector" class="form-control" value="<?php echo htmlentities($result->sector);?>">
</div>
<div class="form-group">
	<div class="col-sm-8 col-sm-offset-2">
		<input type="hidden" name="idedit" value="<?php echo htmlentities($result->id);?>" >
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">STARTER KIT<span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="kit" class="form-control" >
                            <option  value="<?php echo htmlentities($result->kit);?>">Current:"<?php echo htmlentities($result->kit);?>"</option>
                            <option value="no">no</option>
                            <option value="yes">yes</option>
                            </select>
</div><div class="form-group">
<label class="col-sm-2 control-label">phone<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="number" name="phone" class="form-control" value="<?php echo htmlentities($result->phone);?>">
</div>
</div>
<label class="col-sm-2 control-label">Branch</label>
<div class="col-sm-4">
<select name="branch" class="form-control">
<option ><?php echo htmlentities($result->branch);?></option>
<?php
$sql = "SELECT branch from branch";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{
    ?>
    <option><?php echo htmlentities($result->branch);?></option>
    <?php
}};
	?>
                            </select>
</div>

</div>
</div>

<div class="form-group">
	<div class="col-sm-8 col-sm-offset-2">
		<button class="btn btn-primary" name="submit" type="submit" >Save Changes</button>
	</div>
</div>

</form>
									</div>
								</div>
							</div>
						</div>
						
					

					</div>
				</div>
				
			

			</div>
		</div>
	</div>

	<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
	<script type="text/javascript">
				 $(document).ready(function () {          
					setTimeout(function() {
						$('.succWrap').slideUp("slow");
					}, 3000);
					
$("#newModalForm").validate({
  rules: {
	firstame: {
	  required: true,
	  minlength: 3,
	  maxlength:40,
	},
	lastame: {
    required: true,
	  minlength: 3,
	  maxlength:40,
	  
	},
  nid: {
    required: true,
	  minlength: 16,
	  maxlength:16,
	  
	},
  phone: {
    required: true,
	  minlength: 10,
	  maxlength:10,
	  
	},
  ubudehe: {
    required: true,
	  
	  
	},
  edu_level: {
	  required:true,
	  
	},
  gender: {
	  required:true,
	  
	},
  status: {
	  required:true,
	  
	},
  branch: {
	  required:true,
	},
  province: {
	  required:true,
	},
  district: {
	  required:true,
	},
  sector: {
	  required:true,
	},
  },
  messages: {
      fname: {
        required: "Please enter First Name ",
        minlength: "Lastname must  be at least 3 characters long",
	     	maxinlength: "Your Last  must not  be greater than  40 characters long"
      },
	 lname: {
        required: "Please enter last name ",
        minlength: "Lastname must  be at least 3 characters long",
	     	maxinlength: "Your Last  must not  be greater than  40 characters long"
        
      },
      nid: {
        required: "Please enter the  ID ",
        minlength: "NID number must  be at least 16 numbers",
	     	maxinlength: "NID number  must not  be greater than  16 numbers long"
        
      },
      phone: {
        required: "Please enter phone Number ",
        minlength: "phone number must  be at least 10 numbers long",
	     	maxinlength: "Phone numbers  must not  be greater than  10 numbers long"
        
      },
      ubudehe: {
        required: "Please select UBUDEHE Cathegory ",
       
        
      },
      edu_level: {
        required: "Please select Education Level ",
       
        
      },
      gender: {
        required: "Please select Gender ",
       
        
      },
      status: {
        required: "Please select martital Status ",
      },
      branch: {
        required: "Please select branch",
      },
      province: {
        required: "Please select Province",
      },
      district: {
        required: "Please select a district",
      },
      sector: {
        required: "Please select a sector",
      },
    },
	
  
});

					});
	</script>

</body>
</html>
<?php } ?>