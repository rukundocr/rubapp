<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
if(isset($_GET['del']) && isset($_GET['name']))
{
$id=$_GET['del'];
$name=$_GET['name'];

$sql = "delete from users WHERE id=:id";
$query = $dbh->prepare($sql);
$query -> bindParam(':id',$id, PDO::PARAM_STR);
$query -> execute();

$sql2 = "insert into deleteduser (email) values (:name)";
$query2 = $dbh->prepare($sql2);
$query2 -> bindParam(':name',$name, PDO::PARAM_STR);
$query2 -> execute();

$msg="Data Deleted successfully";
}
 ?>

 <?php
if(isset($_POST['save'])){
$branch = $_POST['branch'];
$phone = $_POST['phone'];
$sql = "insert into branch (branch,phone) values (:branch,:phone)";
$query = $dbh->prepare($sql);
$query -> bindParam(':branch',$branch, PDO::PARAM_STR);
$query -> bindParam(':phone',$phone, PDO::PARAM_STR);
if(empty($_POST['branch'])){
$error= "fiels are empty .................";
}
else{
	$query -> execute();
	$msg="branch  $branch added successfully";
}

}
 
 ?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>Branches </title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.6.2/css/buttons.dataTables.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">
  <style>

	.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
	background: #dd3d36;
	color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
	background: #5cb85c;
	color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}

		</style>

</head>

<body>

<div class="modal fade" id="modalRegisterForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-center">
        <h3 class="modal-title w-100 font-weight-bold text-primary">Add Branch</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
     <form method="post" class="form-horizontal" enctype="multipart/form-data" name="imgform" role="form" id="newModalForm">
<div class="form-group">
<label class="col-sm-2 control-label">Branch Name</label>
<div class="col-sm-6">
<input type="text" name="branch" class="form-control" required >
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Phone</label>
<div class="col-sm-6">
<input type="number" name="phone" class="form-control" required >
</div>
</div>


      <div class="modal-footer d-flex justify-content-center">
        <button type="submit" name="save" class="btn btn-primary">SAVE</button>
		<button type="button" class="btn btn-danger" id="btnCloseIt" data-dismiss="modal">Close</button>
      </div>
	  </form>
    </div>
  </div>
</div>

	<?php include('includes/header.php');?>

	<div class="ts-main-content">
		<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">
						<!-- Zero Configuration Table -->
						<div class="panel panel-primary">
							<div class="panel-heading text-center">RUB BRANCHES</a>
							<div class="text-right">
  <a href="add_branch.php" class="text-success mb-2" >Add Branch</a>
</div>
							
							</div>
							<div class="panel-body">
							<?php if($error){?><div class="errorWrap" id="msgshow"><?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div
				 class="succWrap" id="msgshow"><?php echo htmlentities($msg); ?> </div><?php }?>
				<div class="table-responsive table-bordered">
								<table id="12345" class="display table table-striped table-bordered table-hover fetch" cellspacing="0" width="100%">
									<thead>
										<tr>
										<th>#</th>
											
                                                <th>PROVINCE</th>
										        <th>DISTICT</th>
												<th>SECTOR</th>
												<th>BRANCH</th>
												<th>PHONE</th>
                                                <th>PHONE1</th>
												 <th>ACTION</th>
											
										</tr>
									</thead>
									
									<tbody>
									

<?php $sql = "SELECT * from branch order by branch_id DESC";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{				?>
<tr>
<td><?php echo htmlentities($cnt);?></td>
<td><?php echo htmlentities($result->province);?></td>
<td><?php echo htmlentities($result->district);?></td>
<td><?php echo htmlentities($result->sector);?></td>
<td><?php echo htmlentities($result->branch);?></td>
<td><?php echo htmlentities($result->phone);?></td>
<td><?php echo htmlentities($result->phone1);?></td>
<td>
<a href="edit_rub_branch.php?edit=<?php echo $result->branch_id;?>" onclick="return confirm('Do you want to Edit');">&nbsp; <i class="fa fa-pencil"></i></a>&nbsp;&nbsp;

</td>
										</tr>
										<?php $cnt=$cnt+1; }} ?>
										
									</tbody>
								</table>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>

	<!-- Loading Scripts -->
<script src="https://code.jquery.com/jquery-2.2.4.min.js"
	 integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
	  crossorigin="anonymous"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
	<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
	<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
	<script type="text/javascript">
				 $(document).ready(function () {          
					setTimeout(function() {
						$('.succWrap').slideUp("slow");
					}, 3000);
					setTimeout(function() {
						$('.errorWrap').slideUp("slow");
					}, 5000);
					
    $('#12345').DataTable( {
	   "pageLength": 15,
        dom: 'Bfrtip',
        buttons: [
			{
                extend: 'pdfHtml5',
                orientation: 'landscape',
                pageSize: 'LEGAL'
			
			},
              'excel', 'pdf', 'print'
			   
        ]
    } );
   
   

$("#newModalForm").validate({
  rules: {
	branch: {
	  required: true,
	  minlength: 4,
	  maxlength:8,
	},
	email: {
	  required: true,
	   email:true,
	  
	},
	
  },
  messages: {
      branch: {
        required: "Please enter some data",
        minlength: "Your data must be at least 4 characters",
		maxinlength: "Your data must be greater than  8 characters long"
      },
	 email: {
        required: "Please provide your email",
        
      },
     
    },
	
  
});




					});

		</script>
		
</body>
</html>
<?php 

}?>
