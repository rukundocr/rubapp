<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
	?>
<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>Admin panel</title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">
</head>

<body>
<?php include('includes/header.php');?>

	<div class="ts-main-content">
<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">

						<h4 class="page-title">DASHBOARD </h4>
						
						<div class="row">
							<div class="col-md-12">
								<div class="row">
                                  
                                    			<div class="col-md-3">
												<h4 class="text-primary text-center">RUB MEMBERS GENDER CHARTS</h4>
									<canvas id="myChart" width="300" height="300"></canvas>

									</div> 
										<div class="col-md-3">
												<h4 class="text-primary text-center">MRCB TRAINEES GENDER CHARTS</h4>
									<canvas id="myChart2" width="300" height="300"></canvas>

									</div> 

									<div class="col-md-3">
										<div class="panel panel-primary">
											<div class="panel-body bk-info text-light">
												<div class="stat-panel text-center">
<?php 
$sql ="SELECT member_id from members";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$bg=$query->rowCount();
?>
<?php $sql = "SELECT branch
,COUNT(*)as total
,SUM(CASE WHEN gender='Male'THEN 0 else 1 END)AS male
,SUM(CASE WHEN gender='Female'THEN 0 else 1 END)AS female
 from members group by branch" ;
$query = $dbh -> prepare($sql);
$query->execute();
$json3=[];
$json4=[];
while($row=$query->fetch(PDO::FETCH_ASSOC)){
extract($row);
  $json3[]=$branch;
  $json4[]=(int)$total;
 
}
?>

													<div class="stat-panel-number h1 "><?php echo htmlentities($bg);?></div>
													<div class="stat-panel-title text-uppercase"> <i class="fa fa-user fa-3x" aria-hidden="true"></i>  RUB Total members</div>
												</div>
											</div>
											<a href="userlist.php" class="block-anchor panel-footer">Full Detail <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
									
<?php 
$male ="Male";
$sql ="SELECT * from members  where gender = '$male' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$bg=$query->rowCount();
?>
									
<?php 
$female ="Female";
$sql ="SELECT * from members  where gender = '$female' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$bg1=$query->rowCount();
?>
												
									<div class="col-md-3">
										<div class="panel panel-default">
											<div class="panel-body bk-success text-light">
												<div class="stat-panel text-center">

<?php 
$reciver = 'Admin';
$sql1 ="SELECT branch_id from branch ";
$query1 = $dbh -> prepare($sql1);;
$query1-> bindParam(':reciver', $reciver, PDO::PARAM_STR);
$query1->execute();
$results1=$query1->fetchAll(PDO::FETCH_OBJ);
$regbd=$query1->rowCount();
?>
													<div class="stat-panel-number h1 "><?php echo htmlentities($regbd);?></div>
													<div class="stat-panel-title text-uppercase"><i class="fa fa-building fa-3x" aria-hidden="true"></i>  branches</div>
												</div>
											</div>
											<a href="branch.php" class="block-anchor panel-footer text-center">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>

													<div class="col-md-3">
										<div class="panel panel-default">
											<div class="panel-body bk-danger text-light">
												<div class="stat-panel text-center">

<?php 
$reciver = 'Admin';
$sql12 ="SELECT id from trainees ";
$query12 = $dbh -> prepare($sql12);;
$query12-> bindParam(':reciver', $reciver, PDO::PARAM_STR);
$query12->execute();
$results12=$query12->fetchAll(PDO::FETCH_OBJ);
$staff=$query12->rowCount();
?>
													<div class="stat-panel-number h1 "><?php echo htmlentities($staff);?></div>
													<div class="stat-panel-title text-uppercase"> <i class="fa fa-graduation-cap fa-3x" aria-hidden="true"></i>  MRCB TRAINEES</div>
												</div>
											</div>
											<a href="mrcb_trainees.php" class="block-anchor panel-footer text-center">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
																	<div class="panel panel-default">
											<div class="panel-body bk-danger text-light">
												<div class="stat-panel text-center">

<?php 
$reciver = 'Admin';
$sql12 ="SELECT id from rubbord ";
$query12 = $dbh -> prepare($sql12);;
$query12-> bindParam(':reciver', $reciver, PDO::PARAM_STR);
$query12->execute();
$results12=$query12->fetchAll(PDO::FETCH_OBJ);
$board=$query12->rowCount();
?>
													<div class="stat-panel-number h1 "><?php echo htmlentities($board);?></div>
													<div class="stat-panel-title text-uppercase"> <i class="fa fa-user fa-3x" aria-hidden="true"></i>  RUB BOARD & SUB COMMITTEES</div>
												</div>
											</div>
											<a href="rubbord.php" class="block-anchor panel-footer text-center">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
         <!--TRAINEES CHARTS -->

		 
										

<?php 
$male ="Male";
$sql ="SELECT * from trainees  where gender = '$male' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$tmale=$query->rowCount();
?>
									
<?php 
$female ="Female";
$sql ="SELECT * from trainees  where gender = '$female' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$tfemale=$query->rowCount();
?>
													
										
<!--TRAINEES CHARTS -->

									<div class="col-md-3">
										<div class="panel panel-default">
											<div class="panel-body bk-warning text-light">
												<div class="stat-panel text-center">

<?php 

$sql12 ="SELECT id from staff ";
$query12 = $dbh -> prepare($sql12);;
$query12-> bindParam(':reciver', $reciver, PDO::PARAM_STR);
$query12->execute();
$results12=$query12->fetchAll(PDO::FETCH_OBJ);
$staff=$query12->rowCount();
?>
													<div class="stat-panel-number h1 "><?php echo htmlentities($staff);?></div>
													<div class="stat-panel-title text-uppercase"> <i class="fa fa-users fa-3x" aria-hidden="true"></i>  RUB STAFF </div>
												</div>
											</div>
											<a href="rub_stuff.php" class="block-anchor panel-footer text-center">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
									<div class="col-md-3">
										<div class="panel panel-default">
											<div class="panel-body bk-danger text-light">
												<div class="stat-panel text-center">

<?php 

$sql12 ="SELECT id from rubprojects ";
$query12 = $dbh -> prepare($sql12);;
$query12-> bindParam(':reciver', $reciver, PDO::PARAM_STR);
$query12->execute();
$results12=$query12->fetchAll(PDO::FETCH_OBJ);
$rubprojects=$query12->rowCount();
?>
													<div class="stat-panel-number h1 "><?php echo htmlentities($rubprojects);?></div>
													<div class="stat-panel-title text-uppercase"> <i class="fa fa-cogs fa-3x" aria-hidden="true"></i>    RUB PROJECTS </div>
												</div>
											</div>
											<a href="rub_project.php" class="block-anchor panel-footer text-center">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
										<div class="col-md-3">
										<div class="panel panel-default">
											<div class="panel-body bk-primary text-light">
												<div class="stat-panel text-center">

<?php 

$sql12 ="SELECT id from mrcbproject ";
$query12 = $dbh -> prepare($sql12);;
$query12-> bindParam(':reciver', $reciver, PDO::PARAM_STR);
$query12->execute();
$results12=$query12->fetchAll(PDO::FETCH_OBJ);
$mrcbprojects=$query12->rowCount();
?>
													<div class="stat-panel-number h1 "><?php echo htmlentities($mrcbprojects);?></div>
													<div class="stat-panel-title text-uppercase"> <i class="fa fa-cogs fa-3x" aria-hidden="true"></i>    MRCB PROJECTS </div>
												</div>
											</div>
											<a href="mrcb_project.php" class="block-anchor panel-footer text-center">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
									
									<div class="col-md-3">
										<div class="panel panel-default">
											<div class="panel-body bk-success text-light">
												<div class="stat-panel text-center">

<?php 

$sql12 ="SELECT id from mrcbstaff ";
$query12 = $dbh -> prepare($sql12);;
$query12-> bindParam(':reciver', $reciver, PDO::PARAM_STR);
$query12->execute();
$results12=$query12->fetchAll(PDO::FETCH_OBJ);
$staff=$query12->rowCount();
?>
													<div class="stat-panel-number h1 "><?php echo htmlentities($staff);?></div>
													<div class="stat-panel-title text-uppercase"> <i class="fa fa-users fa-3x" aria-hidden="true"></i>  MRCB STAFF </div>
												</div>
											</div>
											<a href="mrcb_stuff.php" class="block-anchor panel-footer text-center">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
									<div class="col-md-3">
										<div class="panel panel-default">
											<div class="panel-body bk-info text-light">
												<div class="stat-panel text-center">
												<?php 
$sql6 ="SELECT id from volunteers ";
$query6 = $dbh -> prepare($sql6);;
$query6->execute();
$results6=$query6->fetchAll(PDO::FETCH_OBJ);
$query=$query6->rowCount();
?>
													<div class="stat-panel-number h1 "><?php echo htmlentities($query);?></div>
													<div class="stat-panel-title text-uppercase">  <i class="fa fa-share-alt-square fa-3x" aria-hidden="true"></i>   VOLUNTEERS</div>
												</div>
											</div>
											<a href="rub_volunteer.php" class="block-anchor panel-footer text-center">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
							       
								</div>
							</div>
						</div>
						<div class="row">
						    	<div class="col-md-12 col-sm-12">
							        <h4 class="text-primary text-center">NUMBER OF MEMBERS BY BRANCH CHARTS</h4>
									<canvas id="myChart1" width="400" height="400"></canvas>

									</div>
					</div>
						
						</div>
					</div>

				</div>
				












			</div>
		</div>
	</div>

	<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.3/dist/Chart.min.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>

	<script>
		
	window.onload = function(){
		//const ctxxx = document.getElementById("myChart2").getContext("2d"); 
		const ctxx = document.getElementById("myChart1").getContext("2d");   
		const ctx = document.getElementById("myChart").getContext("2d");
		const ctxxy = document.getElementById("myChart2").getContext("2d"); 
		const myChart2 = new Chart(ctxxy, {
  type: "pie",
  data: {
    labels: ["Male", "Female"],
    datasets: [
      {
        label: "# Trainees Gender statistics",
        data:[<?php echo (int)$tmale ?>,<?php echo (int)$tfemale?>],
        backgroundColor: [
            "rgba(255, 99, 132, 1)",
          "rgba(54, 162, 235, 1)",
         
          "rgba(255, 206, 86, 0.2)",
          "rgba(75, 192, 192, 0.2)",
          "rgba(153, 102, 255, 0.2)",
          "rgba(255, 159, 64, 0.2)",
        ],
        borderColor: [
           "rgb(255, 191, 0",
          "rgb(255, 128, 0)",
          "rgba(255, 206, 86, 1)",
          "rgba(75, 192, 192, 1)",
          "rgba(153, 102, 255, 1)",
          "rgba(255, 159, 64, 1)",
        ],
        borderWidth: 7,
      },
    ],
  },
  options: {
    scales: {
      yAxes: [
        {
          ticks: {
            beginAtZero: true,
          },
        },
      ],
    },
  },
});
const myChart = new Chart(ctx, {
  type: "pie",
  data: {
    labels: ["Male", "Female"],
    datasets: [
      {
        label: "# Members Gender statistics",
        data:[<?php echo (int)$bg ?>,<?php echo (int)$bg1?>],
        backgroundColor: [
          "rgb(255, 51, 51)",
          "rgb(0,0,255)",
          "rgba(255, 206, 86, 0.2)",
          "rgba(75, 192, 192, 0.2)",
          "rgba(153, 102, 255, 0.2)",
          "rgba(255, 159, 64, 0.2)",
        ],
        borderColor: [
         "rgb(0, 191, 255)",
          "	rgb(0, 255, 191)",
          "rgba(255, 206, 86, 1)",
          "rgba(75, 192, 192, 1)",
          "rgba(153, 102, 255, 1)",
          "rgba(255, 159, 64, 1)",
        ],
        borderWidth: 7,
      },
    ],
  },
  options: {
    scales: {
      yAxes: [
        {
          ticks: {
            beginAtZero: true,
          },
        },
      ],
    },
  },
});
const myChart1 = new Chart(ctxx, {
  type: "horizontalBar",
  data: {
    labels: <?php echo json_encode($json3);?>,
    datasets: [
      {
        label: "# Branch Members: ",
        data:<?php echo json_encode($json4);?>,
        backgroundColor: [
          "rgb(255, 0, 0)",
          "rgb(0,0,0)",
          "rgba(128,0,0)",
          "rgba(255,0,0)",
          "rgba(85,107,47)",
          "rgba(0,255,127)",
		  "rgb(255, 0, 128)",
          "rgb(191, 0, 255)",
          "rgb(0, 0, 255)",
          "rgb(0, 191, 255)",
          "	rgb(0, 255, 191)",
          "rgb(0, 255, 0)",
		  "rgb(255, 0, 0)",
          "	rgb(191, 255, 0)",
          "rgba(0,0,0)",
          "rgb(255, 191, 0",
          "rgb(255, 128, 0)",
          "rgb(0, 0, 0)",
		  "rgb(255, 0, 0)",
          "rgb(77, 0, 0)",
          "rgb(255, 51, 51)",
          "rgb(255, 204, 204)",
          "rgb(128, 128, 128)",
          "rgb(149, 157, 0)",
		  "rgb(255, 0, 0)",
          "rgba(128,0,0)",
          "rgba(255,0,0)",
          "rgba(85,107,47)",
          "rgba(0,255,127)",
		  "rgb(255, 0, 128)",
		  "rgb(255, 0, 128)",
          "rgb(191, 0, 255)",
          "rgb(0, 0, 255)",
          "rgb(0, 191, 255)",
          "	rgb(0, 255, 191)",
          "rgb(0, 255, 0)",
		  "rgb(255, 0, 0)",
          "	rgb(191, 255, 0)",
          "rgba(0,0,0)",
          "rgb(255, 191, 0",
          "rgb(255, 128, 0)",
          "rgb(0, 0, 0)",
		  "rgb(255, 0, 0)",
          "rgb(77, 0, 0)",
          "rgb(255, 51, 51)",
          "rgb(255, 204, 204)",
          "rgb(128, 128, 128)",
          "rgb(149, 157, 0)",
		  "rgb(255, 0, 0)",
         "rgba(128,0,0)",
          "rgba(255,0,0)",
          "rgba(85,107,47)",
          "rgba(0,255,127)",
		  "rgb(255, 0, 128)",
		  "rgb(255, 0, 128)",
          "rgb(191, 0, 255)",
          "rgb(0, 0, 255)",
          "rgb(0, 191, 255)",
          "	rgb(0, 255, 191)",
          "rgb(0, 255, 0)",
		  "rgb(255, 0, 0)",
          "	rgb(191, 255, 0)",
          "rgba(255, 206, 86, 0.2)",
          "rgb(255, 191, 0",
          "rgb(255, 128, 0)",
          "rgb(0, 0, 0)",
		  "rgb(255, 0, 0)",
          "rgb(77, 0, 0)",
          "rgb(255, 51, 51)",
          "rgb(255, 204, 204)",
          "rgb(128, 128, 128)",
          "rgb(149, 157, 0)",
        ],
        borderColor: [
          "rgba(255, 99, 132, 1)",
          "rgba(54, 162, 235, 1)",
          "rgba(255, 206, 86, 1)",
          "rgba(75, 192, 192, 1)",
          "rgba(153, 102, 255, 1)",
          "rgba(255, 159, 64, 1)",
        ],
        borderWidth: 2,
      },
    ],
  },
  options: {
    scales: {
      yAxes: [
        {
          ticks: {
            beginAtZero: true,
          },
        },
      ],
    },
  },
});

	}
	</script>
</body>
</html>
<?php } ?>