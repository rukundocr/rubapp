<?php
require('includes/config.php');

if(isset($_POST['submit']))
{
	$province=$_POST['province'];
    $district=$_POST['district'];
	$sector=$_POST['sector'];
    $phone=$_POST['phone'];
    $phone1=$_POST['phone1'];
    $branch=$_POST['branch'];
	$sql ="SELECT province_name from province  where id = '$province' ";
	$query = $dbh -> prepare($sql);
	$query->execute();
	$results=$query->fetchAll(PDO::FETCH_OBJ);
	foreach($results as $result){
	$newp = $result->province_name;
	 
	}
      
	$sql ="SELECT district_name from districts  where id = '$district' ";
	$query = $dbh -> prepare($sql);
	$query->execute();
	$results=$query->fetchAll(PDO::FETCH_OBJ);
	foreach($results as $result){
	$newD = $result->district_name;

	} 
	  
    $insert_QUERY = $dbh->prepare("INSERT INTO branch (province,district,sector,branch,phone,phone1) 
	  VALUES (:province,:district,:sector,:branch,:phone,:phone1)");

	  $insert_QUERY->bindParam(':province', $newp,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':district', $newD,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':sector', $sector,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':branch', $branch,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':phone', $phone,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':phone1', $phone1,PDO::PARAM_STR);
	
	  $insert_QUERY->execute(); 

	  echo "<div class='alert alert-success'>
	  <a href='userlist.php' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>branch : $branch SAVED  SUCCESSFULLY </b>
	  
	  </div>
	  
		  ";
	 

}

?>

<!DOCTYPE html>
	<head>
	<title></title>
	
	<script src="https://code.jquery.com/jquery-3.5.1.js" 
	integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc="
	 crossorigin="anonymous"></script>
	</head>
	    	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">
	<style>
	.required{
  color:red;
}
.error{
  color:red;
}

</style>
	<body>
	<div class="container">
	<div class="row">
	
	<div class="modal fade" id="modalRegisterForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-center">
        <h3 class="modal-title w-100 font-weight-bold text-primary">ADD BRANCH</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
<h5 class="text-default">Fileds with <span class="required">*</span>are mandatory</h5>
 <form method="post" action="add_branch.php" class="form-horizontal" enctype="multipart/form-data" name="imgform" id="newModalForm" onSubmit ="return valid();">


<div class="form-group">
<label class="col-sm-2 control-label">Province<span class="required">*</span></label>
<div class="col-sm-4">
<select  id="province" name="province" class="form-control">
		                    	<option selected="" disabled="">Select Province</option>
		                    	<?php 
		                    		require 'data.php';
		                    		$authors = loadAuthors();
		                    		foreach ($authors as $author) {
		                    			echo "<option id='".$author['id']."' value='".$author['id']."'>".$author['province_name']."</option>";
		                    		}
		                    	 ?>
		                    </select>

</div>

<label class="col-sm-2 control-label">District<span class="required">*</span></label>
<div class="col-sm-4">
<select  id="district" name="district"class="form-control">
		                    <option selected="" disabled="">Select District</option>
		                    </select>
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Sector <span class="required">*</span></label>
<div class="col-sm-4">
<select  id="sector" name="sector" class="form-control">
							<option selected="" disabled="">Select Sector</option>
		                    </select>
</div>

<label class="col-sm-2 control-label">BRANCH NAME <span class="required">*</span></label>
<div class="col-sm-4">
<input  type="text" id="branch" name="branch" class="form-control">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">PHONE<span class="required">*</span></label>
<div class="col-sm-4">
<input  type="number" id="phone" name="phone" class="form-control">
</div>

<label class="col-sm-2 control-label">ALTERNATIVE PHONE<span class="required">*</span></label>
<div class="col-sm-4">
<input  type="number" id="phone1" name="phone1" class="form-control">
</div>
</div>

<div class="form-group">
	<div class="col-sm-8 col-sm-offset-2">
		<input type="hidden" name="idedit"  >
</div>
</div>
      <div class="modal-footer d-flex justify-content-center">
        <button type="submit" name="submit" class="btn btn-primary">SAVE</button>
		<button type="button" class="btn btn-danger" id="btnCloseIt" data-dismiss="modal">Close</button>
      </div>
	 
    </div>
	</form>
  </div>
</div>
	
	
	</div>
	
	</div>

</div>
<div class="container">
<div class="row">
<div class="col ">
<div class='center'>
	<div class="card ">

<!-- Card image -->
<div class="view overlay">
  <img class="card-img-top responsive" src="https://mdbootstrap.com/img/Mockups/Lightbox/Thumbnail/img%20(67).jpg"
	alt="Card image cap">
  <a href="#!">
	<div class="mask rgba-white-slight"></div>
  </a>
</div>

<!-- Card content -->
<div class="card-body">

  <!-- Title -->
  <h4 class="card-title">ADD BRANCH ROOM</h4>
  <a href="" class="btn btn-primary"  data-toggle="modal" data-target="#modalRegisterForm">ADD BRANCH</a>
  <a href="branch.php" class=" btn btn-success" >BACK TO BRANCH LIST</a>
</div>
	<!-- Card -->
</div>

</div>
</div>

<script src= "main1.js"></script>
	<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
	<script src="js/main.js"></script>
	<script type="text/javascript">
				 $(document).ready(function () {          
					setTimeout(function() {
						$('.succWrap').slideUp("slow");
					}, 3000);
					setTimeout(function() {
						$('.errorWrap').slideUp("slow");
					}, 5000);

					

$("#newModalForm").validate({
  rules: {
	firstname: {
	  required: true,
	  minlength: 3,
	  maxlength:40,
	},
	lastname: {
    required: true,
	  minlength: 3,
	  maxlength:40,
	  
	},
  nid: {
    required: true,
	  minlength: 16,
	  maxlength:16,
	  
	},
  phone: {
    required: true,
	  minlength: 10,
	  maxlength:10,
	  
	},
  ubudehe: {
    required: true,
	  
	  
	},
  education: {
	  required:true,
	  
	},
  gender: {
	  required:true,
	  
	},
  status: {
	  required:true,
	  
	},
  branch: {
	  required:true,
	},
  province: {
	  required:true,
	},
  district: {
	  required:true,
	},
  sector: {
	  required:true,
	},
	year: {
	  required:true,
	},
  birthdate: {
	  required:true,
	},
  occupation: {
	  required:true,
	},
	cause: {
	  required:true,
	},
  vstatus: {
	  required:true,
	},
	other: {
	  required:true,
	},
  },
  messages: {
      firstname: {
        required: "Please enter First Name ",
        minlength: "Lastname must  be at least 3 characters long",
	     	maxinlength: "Your Last  must not  be greater than  40 characters long"
      },
	 lastname: {
        required: "Please enter last name ",
        minlength: "Lastname must  be at least 3 characters long",
	     	maxinlength: "Your Last  must not  be greater than  40 characters long"
        
      },
      nid: {
        required: "Please enter the  ID ",
        minlength: "NID number must  be at least 16 numbers",
	     	maxinlength: "NID number  must not  be greater than  16 numbers long"
        
      },
      phone: {
        required: "Please enter phone Number ",
        minlength: "phone number must  be at least 10 numbers long",
	     	maxinlength: "Phone numbers  must not  be greater than  10 numbers long"
        
      },
      ubudehe: {
        required: "Please select UBUDEHE Cathegory ",
       
        
      },
      education: {
        required: "Please select Education Level ",
       
        
      },
      gender: {
        required: "Please select Gender ",
       
        
      },
      status: {
        required: "Please select martital Status ",
      },
      branch: {
        required: "Please select branch",
      },
      province: {
        required: "Please select Province",
      },
      district: {
        required: "Please select a district",
      },
      sector: {
        required: "Please select a sector",
	  },
      year: {
        required: "Please year",
      },
      birthdate: {
        required: "birthdate is required",
      },
      occupation: {
        required: "occupation is required",
      },
      vstatus: {
        required: "visual status is required",
	  },
	  other: {
        required: "visual status is required",
      },
    
    },
	
  
});




					});
          </script>
	</body>
</html>