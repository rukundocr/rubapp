<?php
namespace Phppot;

use Phppot\DataSource;

class CountryStateCity
{
    private $ds;
    
    function __construct()
    {
        require_once __DIR__ . './../lib/DataSource.php';
        $this->ds = new DataSource();
    }
    
    /**
     * to get the country record set
     *
     * @return array result record
     */
    public function getAllCountry()
    {
        $query = "SELECT * FROM province";
        $result = $this->ds->select($query);
        return $result;
    }
    public function getAllbranch()
    {
        $query = "SELECT * FROM branch";
        $result = $this->ds->select($query);
        return $result;
    }
    

    public function getStateByCountrId($provinceId)
    {
        $query = "SELECT * FROM districts WHERE province_id = ?";
        $paramType = 'd';
        $paramArray = array(
            $provinceId
        );
        $result = $this->ds->select($query, $paramType, $paramArray);
        return $result;
    }
    
    /**
     * to get the city record based on the state_id
     *
     * @param string $stateId
     * @return array result record
     */
    public function getSectorByDistrictid($districtid)
    {
        print $query = "SELECT * FROM sectors WHERE district_id = ?";
        $paramType = 'd';
        $paramArray = array(
            $districtid
        );
        $result = $this->ds->select($query, $paramType, $paramArray);
        return $result;
    }
}