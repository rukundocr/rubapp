<?php 
	require 'DbConnect.php';

	if(isset($_POST['aid'])) {      
	
		$db = new DbConnect;
		$conn = $db->connect();
		$id = $_POST['aid'];
		$stmt = $conn->prepare("SELECT * FROM districts WHERE province_id = '$id'");
		$stmt->execute();
		$books = $stmt->fetchAll(PDO::FETCH_ASSOC);
		echo json_encode($books);
	}
	if(isset($_POST['sec'])) {
		$db = new DbConnect;
		$conn = $db->connect();

		$stmt = $conn->prepare("SELECT * FROM sectors WHERE district_id = " . $_POST['sec']);
		$stmt->execute();
		$books = $stmt->fetchAll(PDO::FETCH_ASSOC);
		echo json_encode($books);
	}

	function loadAuthors() {
		$db = new DbConnect;
		$conn = $db->connect();
		$stmt = $conn->prepare("SELECT * FROM province");
		$stmt->execute();
		$authors = $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $authors;
	}
	function loadBranches() {
		$db = new DbConnect;
		$conn = $db->connect();

		$stmt = $conn->prepare("SELECT * FROM branch");
		$stmt->execute();
		$branches= $stmt->fetchAll(PDO::FETCH_ASSOC);
		return $branches;
	}
	if(isset($_POST['submit'])) {
		$province = $_POST['province'];
	    $district= $_POST['district'];
		$sector = $_POST['sector'];
		
	}

 ?>