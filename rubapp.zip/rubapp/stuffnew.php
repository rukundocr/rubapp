<?php
namespace Phppot;
use Phppot\CountryState;
require_once __DIR__ . '/Model/CountryStateCity.php';
include("connect.php");
$countryStateCity = new CountryStateCity();
$countryResult = $countryStateCity->getAllCountry();
$branchResults = $countryStateCity->getAllbranch();

if(isset($_POST['submit'])){
    $firstname=$_POST['fname'];
    $lastname=$_POST['lname'];
    $nid=$_POST['nid'];
    $education=$_POST['education'];
    $hired=$_POST['hired'];
    $gender =$_POST['gender'];
    $status=$_POST['status'];
    $phone=$_POST['phone'];
    $birthdate=$_POST['birthdate'];
    $rssbnumber=$_POST['rssbnumber'];
    $whour=$_POST['whour'];
    $salary=$_POST['salary'];
    $position=$_POST['position'];
    $email=$_POST['email'];
    $residence=$_POST['residence'];
    $insurance=$_POST['insurance'];
    

  $insert_QUERY = ("INSERT INTO  staff (firstname, lastname,gender, m_status,bdate, NID,hiredate, rssbnumber,insurance,
   whour,salary, education,position, residence, email,phone) 
  VALUES ('$firstname', '$lastname','$gender', '$status','$birthdate','$nid','$hired','$rssbnumber','$insurance','$whour',:$salary,'$education','$position','$residence', '$email','$phone')");
   $run = mysqli_query($conn,$insert_QUERY);
  echo "done";
  $msg = "staff member $firstname added well";
}
}
?>
<html>
<head>
<TITLE>select</TITLE>
<head>
<link href="./assets/css/style.css" rel="stylesheet" type="text/css" />
<script src="./vendor/jquery/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="./assets/js/ajax-handler.js" type="text/javascript"></script>

</head>
<style>
.required{
  color:red;
}
.error{
  color:red;
}

</style>
<body>

<div class="modal fade" id="modalRegisterForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-center">
        <h3 class="modal-title w-100 font-weight-bold text-primary">Add Member</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
 <form method="post" class="form-horizontal" enctype="multipart/form-data" name="imgform" id="newModalForm" onSubmit ="return valid();">
<div class="form-group">
<label class="col-sm-2 control-label">First name</label>
<div class="col-sm-4">
<input type="text" name="fname" placeholder ="First name" class="form-control">
</div>
<label class="col-sm-2 control-label">Last name</label>
<div class="col-sm-4">
<input type="text" name="lname"  placeholder ="last name" class="form-control" >
</div>
</div>
<div class="form-group">

<label class="col-sm-2 control-label">Gender</label>
<div class="col-sm-4">
<select name="gender"  class="form-control" >
                            <option selected disabled >select  your gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            </select>
</div>
<label class="col-sm-2 control-label">Marital Status<span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="status"  class="form-control" >
                            <option selected disabled >select  Marital Status</option>
                            <option value="single">single</option>
  <option value="married">married</option>
  <option value="divorced">Divorced</option>
  <option value="widowed">Widowed</option>
                            </select>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Nid</label>
<div class="col-sm-4">
<input type="number" name="nid" placeholder ="Enter NID" class="form-control" >
</div>
<label class="col-sm-2 control-label">Rssb number</label>
<div class="col-sm-4">
<input type="text" name="rssbnumber" placeholder ="Enter RSSB number" class="form-control"  >
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Birth_date</label>
<div class="col-sm-4">
<input type="date" name="birthdate" placeholder ="select date" class="form-control" >
</div>

<label class="col-sm-2 control-label">Insurence</label>
<div class="col-sm-4">
<input type="text" name="insurance" placeholder ="Enter Insurance number" class="form-control"  >
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Hired_date</label>
<div class="col-sm-4">
<input type="date" name="hired" placeholder ="select hired date" class="form-control" >
</div>

<label class="col-sm-2 control-label">Phone</label>
<div class="col-sm-4">
<input type="number" name="phone" placeholder ="Enter phone numbers" class="form-control"  >
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Work Hours</label>
<div class="col-sm-4">
<input type="number" name="whour" placeholder =" Work hours" class="form-control" >
</div>

<label class="col-sm-2 control-label">salary</label>
<div class="col-sm-4">
<input type="text" name="salary" placeholder ="Enter salary"  class="form-control"  >
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Education</label>
<div class="col-sm-4">
<select name="education" class="form-control"  >
                            <option selected disabled >select to change your education </option>
                            <option value="secondary">A2 Certificate</option>
                            <option value="University">bachelors degree</option>
                            <option value="Masters">Masters</option>
                            <option value="phd">Phd</option>
                            <option value="none">None</option>
                            </select>

</div>

<label class="col-sm-2 control-label">Position</label>
<div class="col-sm-4">
<input type="text" name="position" placeholder ="Position" class="form-control"  >
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Residence </label>
<div class="col-sm-4">
<input type="text" name="residence" placeholder ="Residence" class="form-control"  >
</div>

<label class="col-sm-2 control-label">Email</label>
<div class="col-sm-4">
<input type="email" name="email" placeholder ="Enter Email" class="form-control" >
</div>
</div>

<div class="form-group">
	<div class="col-sm-8 col-sm-offset-2">
		<input type="hidden" name="idedit"  >
</div>
</div>
      <div class="modal-footer d-flex justify-content-center">
        <button type="submit" name="submit" class="btn btn-primary">SAVE</button>
		<button type="button" class="btn btn-danger" id="btnCloseIt" data-dismiss="modal">Close</button>
      </div>
	 
    </div>
	</form>
  </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
<script type="text/javascript">
				 $(document).ready(function () {          
					setTimeout(function() {
						$('.succWrap').slideUp("slow");
					}, 3000);
					setTimeout(function() {
						$('.errorWrap').slideUp("slow");
					}, 5000);

					

$("#newModalForm").validate({
  rules: {
	fname: {
	  required: true,
	  minlength: 3,
	  maxlength:40,
	},
	lname: {
    required: true,
	  minlength: 3,
	  maxlength:40,
	  
	},
  nid: {
    required: true,
	  minlength: 16,
	  maxlength:16,
	  
	},
  phone: {
    required: true,
	  minlength: 10,
	  maxlength:10,
	  
	},
  ubudehe: {
    required: true,
	  
	  
	},
  edu_level: {
	  required:true,
	  
	},
  gender: {
	  required:true,
	  
	},
  status: {
	  required:true,
	  
	},
  branch: {
	  required:true,
	},
  country: {
	  required:true,
	},
  state: {
	  required:true,
	},
  city: {
	  required:true,
	},
  },
  messages: {
      fname: {
        required: "Please enter First Name ",
        minlength: "Lastname must  be at least 3 characters long",
	     	maxinlength: "Your Last  must not  be greater than  40 characters long"
      },
	 lname: {
        required: "Please enter last name ",
        minlength: "Lastname must  be at least 3 characters long",
	     	maxinlength: "Your Last  must not  be greater than  40 characters long"
        
      },
      nid: {
        required: "Please enter the  ID ",
        minlength: "NID number must  be at least 16 numbers",
	     	maxinlength: "NID number  must not  be greater than  16 numbers long"
        
      },
      phone: {
        required: "Please enter phone Number ",
        minlength: "phone number must  be at least 10 numbers long",
	     	maxinlength: "Phone numbers  must not  be greater than  10 numbers long"
        
      },
      ubudehe: {
        required: "Please select UBUDEHE Cathegory ",
       
        
      },
      edu_level: {
        required: "Please select Education Level ",
       
        
      },
      gender: {
        required: "Please select Gender ",
       
        
      },
      status: {
        required: "Please select martital Status ",
      },
      branch: {
        required: "Please select branch",
      },
      country: {
        required: "Please select Province",
      },
      state: {
        required: "Please select a district",
      },
      city: {
        required: "Please select a sector",
      },
    },
	
  
});




					});
          </script>
</body>
</html>