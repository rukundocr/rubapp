<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
if(isset($_GET['del']))
{
$id=$_GET['del'];

$sql = "delete from volunteers WHERE id=:id";
$query = $dbh->prepare($sql);
$query -> bindParam(':id',$id, PDO::PARAM_STR);
$query -> execute();

$sql2 = "insert into deleteduser (email) values (:name)";
$query2 = $dbh->prepare($sql2);
$query2 -> bindParam(':name',$name, PDO::PARAM_STR);
$query2 -> execute();

$msg="Data Deleted successfully";
}

if(isset($_REQUEST['unconfirm']))
	{
	$aeid=intval($_GET['unconfirm']);
	$memstatus=1;
	$sql = "UPDATE users SET status=:status WHERE  id=:aeid";
	$query = $dbh->prepare($sql);
	$query -> bindParam(':status',$memstatus, PDO::PARAM_STR);
	$query-> bindParam(':aeid',$aeid, PDO::PARAM_STR);
	$query -> execute();
	$msg="Changes Sucessfully";
	}

	if(isset($_REQUEST['confirm']))
	{
	$aeid=intval($_GET['confirm']);
	$memstatus=0;
	$sql = "UPDATE users SET status=:status WHERE  id=:aeid";
	$query = $dbh->prepare($sql);
	$query -> bindParam(':status',$memstatus, PDO::PARAM_STR);
	$query-> bindParam(':aeid',$aeid, PDO::PARAM_STR);
	$query -> execute();
	$msg="Changes Sucessfully";
	}
	 
	if(isset($_POST['submit'])){
		$first=$_POST['first'];
		$lastname=$_POST['lastname'];
		$nid =$_POST['nid'];
		$education=$_POST['education'];
		$gender =$_POST['gender'];
		$status=$_POST['status'];
		$phone=$_POST['phone'];
		$birthdate=$_POST['birthdate'];
		$localbranch=$_POST['localbranch'];
		$membership=$_POST['membership'];
		$adress=$_POST['adress'];
		$email=$_POST['email'];
	
	  $insert_QUERY = $dbh->prepare("INSERT INTO volunteers (lastname,nid,education,gender,status,phone,bdate,localbranch,rubmembership,adress,email,first) 
	  VALUES (:lastname,:nid,:education,:gender,:status,:phone,:birthdate,:localbranch,:membership,:adress,:email,:first)");

	  $insert_QUERY->bindParam(':lastname', $lastname,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':nid', $nid,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':education', $education,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':gender', $gender,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':status', $status,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':phone', $phone,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':birthdate', $birthdate,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':localbranch', $localbranch,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':membership', $membership,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':adress', $adress,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':email', $email,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':first', $first,PDO::PARAM_STR);
	  
	  $insert_QUERY->execute(); 
	  echo "$lastname";
	  $msg = "Project  $lastname is  added successfully";

	}




 ?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>VOLUNTEERS</title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">
  <style>

	.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
	background: #dd3d36;
	color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
	background: #5cb85c;
	color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.error{
	color:red;
}
.requied{
	color:red;
}

		</style>

</head>

<body>

<div class="modal fade" id="modalRegisterForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-center">
        <h3 class="modal-title w-100 font-weight-bold text-primary">Add Volunteer</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
	  <h5 class="text-default">Fileds with <span class="required">*</span>are mandatory</h5>
<form method="post" class="form-horizontal" enctype="multipart/form-data" name="imgform" id ="newModalForm">
<div class="form-group">
<label class="col-sm-2 control-label">First name</label>
<div class="col-sm-4">
<input type="text" name="first" placeholder ="First name" class="form-control"  >
</div>
<label class="col-sm-2 control-label">Last name</label>
<div class="col-sm-4">
<input type="text" name="lastname" placeholder ="Last Name" class="form-control" >
</div>
</div>
<div class="form-group">

<label class="col-sm-2 control-label">Gender</label>
<div class="col-sm-4">
<select name="gender" class="form-control" >
                            <option selected disabled >select to change your gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            </select>
</div>
<label class="col-sm-2 control-label">status<span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="status"  class="form-control" >
                            <option selected disabled >select  Marital Status<span class="required">*</span></option>
                            <option value="single">single</option>
  <option value="married">married</option>
  <option value="divorced">Divorced</option>
  <option value="widowed">Widowed</option>
                            </select>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">NID</label>
<div class="col-sm-4">
<input type="number" name="nid" placeholder="National ID" class="form-control" >
</div>
<label class="col-sm-2 control-label">Rub membership</label>
<div class="col-sm-4">
<input type="text" name="membership" placeholder="RUB Membership" class="form-control"  >
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Birth_date</label>
<div class="col-sm-4">
<input type="date" name="birthdate" class="form-control" >
</div>

<label class="col-sm-2 control-label">local_branch</label>
<div class="col-sm-4">
<input type="text" name="localbranch" placeholder="Local branch" class="form-control" >
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Education</label>
<div class="col-sm-4">
<select name="education" class="form-control" >
                            <option selected disabled >select  education </option>
                            <option value="primary">primary</option>
                            <option value="secondary">secondary</option>
                            <option value="University">University</option>
                            <option value="Masters">Masters</option>
                            <option value="phd">Phd</option>
                            <option value="none">None</option>
                            </select>
</div>

<label class="col-sm-2 control-label">Address</label>
<div class="col-sm-4">
<input type="text" name="adress" placeholder="adress" class="form-control" ">
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Phone </label>
<div class="col-sm-4">
<input type="number" name="phone" placeholder="Phone number" class="form-control"  >
</div>

<label class="col-sm-2 control-label">Email</label>
<div class="col-sm-4">
<input type="email" name="email"  placeholder="enter email" class="form-control" >
</div>
</div>
<div class="form-group">
	<div class="col-sm-8 col-sm-offset-2">
		<input type="hidden" name="idedit"  >
</div>
</div>

<div class="form-group">
<div class="modal-footer d-flex justify-content-center">
        <button type="submit" name="submit" class="btn btn-primary">SAVE</button>
		<button type="button" class="btn btn-danger" id="btnCloseIt" data-dismiss="modal">Close</button>
      </div>
</div>

</form>
    </div>
  </div>
</div>


	<?php include('includes/header.php');?>

	<div class="ts-main-content">
		<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">

				

						<!-- Zero Configuration Table -->
						<div class="panel panel-primary">
							<div class="panel-heading text-center">RUB VOLUNTEERS 
							<div class="text-right">
  <a href="" class="text-success mb-2" data-toggle="modal" data-target="#modalRegisterForm">Add Volunteer</a>
</div>
							</div>
							<div class="panel-body">
							<?php if($error){?><div class="errorWrap" id="msgshow"><?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap" id="msgshow"><?php echo htmlentities($msg); ?> </div><?php }?>
								<div class="table-responsive table-bordered">
								<table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
									<thead>
										<tr>
										<th>#</th>
											
                                                <th>first name</th>
                                                <th>last name</th>
                                                <th>Gender</th>
                                                <th>status</th>
												<th>phone number</th>
												<th>education</th>
												<th>address</th>
												<th>Rub_membership</th>
												<th>LOCAL BRANCH</th>
												<th>Nid</th>
												<th>email</th>
											<th>Action</th>	
										</tr>
									</thead>
									
									<tbody>

<?php $sql = "SELECT * from volunteers order by id DESC";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{				?>	
<tr>
<td><?php echo htmlentities($cnt);?></td>
<td><?php echo htmlentities($result->first);?></td>
<td><?php echo htmlentities($result->lastname);?></td>
<td><?php echo htmlentities($result->gender);?></td>
<td><?php echo htmlentities($result->status);?></td>
<td><?php echo htmlentities($result->phone);?></td>
<td><?php echo htmlentities($result->education);?></td>
<td><?php echo htmlentities($result->adress);?></td>
<td><?php echo htmlentities($result->rubmembership);?></td>
<td><?php echo htmlentities($result->localbranch);?></td>
<td><?php echo htmlentities($result->nid);?></td>
<td><?php echo htmlentities($result->email);?></td>

											
<td>
<a href="edit_rub_volunteer.php?edit=<?php echo $result->id;?>" onclick="return confirm('Do you want to Edit');">&nbsp; <i class="fa fa-pencil"></i></a>&nbsp;&nbsp;
<a href="rub_volunteer.php?del=<?php echo $result->id;?>&name=<?php echo htmlentities($result->email);?>" onclick="return confirm('Do you want to Delete');"><i class="fa fa-trash" style="color:red"></i></a>&nbsp;&nbsp;
</td>
										</tr>
										<?php $cnt=$cnt+1; }} ?>
										
									</tbody>
								</table>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>

	<!-- Loading Scripts -->
	<script src="https://code.jquery.com/jquery-2.2.4.min.js"
	 integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
	  crossorigin="anonymous"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
	<script type="text/javascript">
				 $(document).ready(function () {          
					setTimeout(function() {
						$('.succWrap').slideUp("slow");
					}, 3000);

					$("#newModalForm").validate({
  rules: {
	first: {
	  required: true,
	  minlength: 3,
	  maxlength:40,
	},
	lastname: {
    required: true,
	  minlength: 3,
	  maxlength:40,
	  
	},
  nid: {
    required: true,
	  minlength: 16,
	  maxlength:16,
	  
	},
  phone: {
    required: true,
	  minlength: 10,
	  maxlength:10,
	  
	},
  education: {
	  required:true,
	  
	},
  gender: {
	  required:true,
	  
	},
  status: {
	  required:true,
	  
	},
  email: {
	  required:true,
	},
  localbranch: {
	  required:true,
	 
	},
	membership: {
	  required:true,
	},
	adress: {
	  required:true,
	},
	birthdate: {
	  required:true,
	},
  },
  messages: {
      first: {
        required: "Please enter First Name ",
        minlength: "Lastname must  be at least 3 characters long",
	     	maxinlength: "Your Last  must not  be greater than  40 characters long"
      },
	 lastname: {
        required: "Please enter last name ",
        minlength: "Lastname must  be at least 3 characters long",
	     	maxinlength: "Your Last  must not  be greater than  40 characters long"
        
      },
      nid: {
        required: "Please enter the  ID ",
        minlength: "NID number must  be at least 16 numbers",
	     	maxinlength: "NID number  must not  be greater than  16 numbers long"
        
      },
      phone: {
        required: "Please enter phone Number ",
        minlength: "phone number must  be at least 10 numbers long",
	     	maxinlength: "Phone numbers  must not  be greater than  10 numbers long"
        
      },
    
      education: {
        required: "Please select Education Level ",
       
        
      },
      gender: {
        required: "Please select Gender ",
       
      },
      status: {
        required: "Please select martital Status ",
      },
      email: {
        required: "Please enter email",
      },
      adress: {
        required: "Please provide adress",
      },
      membership: {
        required: "Please Rub membership",
      },
	  localbranch: {
        required: "Please local branch name ",
      },
	  birthdate: {
        required: "Please provide birth date ",
      },
    },
	
  
});
	
					});
		</script>
		
</body>
</html>
<?php } ?>
