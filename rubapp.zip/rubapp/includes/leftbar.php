	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main Navigation</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i>&nbsp; RUB DASHBOARD</a></li>
			    <li class="ts-account">
				 <a href="#"><i class="fa fa-user"></i>Account</a>
				 <ul>
				 <!--<li><a href="profile.php"></i> &nbsp;PROFILE</a></li>-->
				 <li><a href="change-password.php">Change Password</a></li>
					<li><a href="logout.php">Logout</a></li>
				 </ul>
				</li>
		
			    
			

			<li class="ts-account">
				<a href="#"> <i class="fa fa-user"></i> &nbsp;RUB</a>
				<ul>
					<li><a href="userlist.php">RUB MEMBERS</a></li>
					<li><a href="branch.php">BRANCHES</a></li>
					<li><a href="rub_branch.php">BRANCH STATISTICS</a></li>
					<li><a href="rub_stuff.php">RUB_STUFF</a></li>
					<li><a href="rubbord.php">RUB_BOARD</a></li>
					<li><a href="rub_volunteer.php">RUB_VOLUNTEERS</a></li>
					<li><a href="rub_project.php">RUB_PROJECT</a></li>
				</ul>
			</li>
	             
	
			</li>

			<li class="ts-account">
				<a href="#"> <i class="fa fa-user"></i>&nbsp;MRCB </a>
				<ul>
					<li ><a href="mrcb_stuff.php">MRCB_STUFF</a></li>
					<li><a href="mrcb_project.php">MRCB_PROJECT</a></li>
					<li><a href="mrcb_trainees.php">MRCB_TRAINEES</a></li>
				</ul>
			</li>

			
			<li class="ts-account">
				<a href="#"> <i class="fa fa-download"></i>&nbsp;Downloads</a>
				<ul>
				<li><a href="d_members.php"><i class="fa fa-download"></i> &nbsp;Download Members LIST</a>
			    <li><a href="historical.php"><i class="fa fa-download"></i> &nbsp;Download Branch LIST</a>
				<li><a href="d_trainnes.php"><i class="fa fa-download"></i> &nbsp;Download Trainnes LIST</a>
				<li><a href="d_voluntees.php"><i class="fa fa-download"></i> &nbsp;Download Volunteers  LIST</a>
				<li><a href="d_rub_staff.php"><i class="fa fa-download"></i> &nbsp;Download RUB STAFF LIST</a>
				<li><a href="d_mrcb_staff.php"><i class="fa fa-download"></i> &nbsp;Download MRCB STAFF LIST</a>
				</ul>
			</li>

			</ul>
			
		</nav>
