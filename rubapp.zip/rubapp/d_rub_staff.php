<?php 
session_start();
//error_reporting(0);
session_regenerate_id(true);
include('includes/config.php');

if(strlen($_SESSION['alogin'])==0)
	{	
	header("Location: login.php"); //
	}
	else{?>
<table border="1">
									<thead>
										<tr>
										<th>#</th>
                                                <th>FIRSTNAME</th>
												<th>LASTNAME</th>
												<th>GENDER</th>
                                                <th>PHONE</th>
                                                <th>NID</th>
                                                <th>EDUCATION</th>
												<th>POSITION</th>
												<th>RESIDENCE</th>
												<th>MARITAL STATUS</th>
                                                <th>BIRTHDATE</th>
												<th>RSSB NUMBER</th>
												<th>INSURANCE NUMBER</th>
                                                <th>WORK HOURS</th>
												<th>SALARY</th>
												<th>EMAIL</th>
                                              
											
										
										</tr>
									</thead>

<?php 
$filename="rub_staff_list";
 $sql = "SELECT * from staff order by id DESC";
						
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{				

echo '  
<tr>  
<td>'.$cnt.'</td> 
<td>'.$province= $result->firstname.'</td> 
<td>'.$district= $result->lastname.'</td> 
<td>'.$sector= $result->gender.'</td> 
<td>'.$firstname= $result->phone.'</td> 
<td>'.$lastname= $result->NID.'</td> 
<td>'.$gender= $result->education.'</td> 
<td>'.$m_status= $result->position.'</td> 
<td>'.$phone= $result->residence.'</td> 
<td>'.$ubudehe= $result->m_status.'</td> 
<td>'.$branch= $result->bdate.'</td> 
<td>'.$nid= $result->rssbnumber.'</td> 
<td>'.$edu_level= $result->insurance.'</td> 
<td>'.$branch= $result->whour.'</td> 
<td>'.$nid= $result->salary.'</td> 
<td>'.$edu_level= $result->email.'</td> 				
</tr>  
';
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=".$filename."-report.xls");
header("Pragma: no-cache");
header("Expires: 0");
			$cnt++;
			}
	}
?>
</table>
<?php } ?>