<?php 
session_start();
//error_reporting(0);
session_regenerate_id(true);
include('includes/config.php');

if(strlen($_SESSION['alogin'])==0)
	{	
	header("Location: login.php"); //
	}
	else{?>
<table border="1">
									<thead>
										<tr>
										<th>#</th>
                                                <th>Province</th>
												<th>District</th>
												<th>Sector</th>
                                                <th>first name</th>
                                                <th>last name</th>
                                                <th>Gender</th>
												<th>Marital Status</th>
												<th>phone number</th>
												<th>ubudehe</th>
                                                <th>Branch</th>
												<th>NID</th>
												<th>Education Level</th>
                                                <th>OCCUPATION</th>
                                                <th>BIRTHDATE</th>
                                                <th>Registration date</th>
                                                <th>GRADUATION DATE</th>
                                                <th>STARTER KIT</th>
                                                <th>VISUAL STATUS</th>
											
										
										</tr>
									</thead>

<?php 
$filename="trainnes_list";
 $sql = "SELECT * from trainees order by id DESC";
						
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{				

echo '  
<tr>  
<td>'.$cnt.'</td> 
<td>'.$province= $result->province.'</td> 
<td>'.$district= $result->district.'</td> 
<td>'.$sector= $result->sector.'</td> 
<td>'.$firstname= $result->firstname.'</td> 
<td>'.$lastname= $result->lastname.'</td> 
<td>'.$gender= $result->gender.'</td> 
<td>'.$m_status= $result->m_status.'</td> 
<td>'.$phone= $result->phone.'</td> 
<td>'.$ubudehe= $result->ubudehe.'</td> 
<td>'.$branch= $result->branch.'</td> 
<td>'.$nid= $result->nid.'</td> 
<td>'.$edu_level= $result->edu_level.'</td> 	
<td>'.$occupation= $result->occupation.'</td> 
<td>'.$birthdate =$result->birthdate.'</td> 
<td>'.$cuase_visual= $result->regdate.'</td> 
<td>'.$occupation= $result->gradate.'</td> 
<td>'.$birthdate =$result->kit.'</td> 
<td>'.$birthdate =$result->visual_status.'</td> 
	
				
</tr>  
';
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=".$filename."-report.xls");
header("Pragma: no-cache");
header("Expires: 0");
			$cnt++;
			}
	}
?>
</table>
<?php } ?>