$(document).ready(function(){
    //province select
    $("#province").change(function(){
        var aid = $("#province").val();
        $.ajax({
            url: 'data.php',
            method: 'post',
            data: 'aid=' + aid
        }).done(function(books){
            console.log(books);
            books = JSON.parse(books);
            $('#district').empty();
            books.forEach(function(book){
                $('#district').append('<option value="'+ book.id +'">' + book.district_name + '</option>')
            })
        })
    })
    //district select
    $("#district").change(function(){
        var sec = $("#district").val();
        $.ajax({
            url: 'data.php',
            method: 'post',
            data: 'sec=' +  sec
        }).done(function(books){
            console.log(books);
            books = JSON.parse(books);
            $('#sector').empty();
            books.forEach(function(book){
                $('#sector').append('<option >' + book.sector_name + '</option>');
            })
        })
    })
    
})


	