<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{

if(isset($_GET['edit']))
	{
		$editid=$_GET['edit'];
	}


	
if(isset($_POST['submit']))
  {
	
	$idedit=$_POST['idedit'];
	$projecttitle=$_POST['projecttitle'];
	$prodescription=$_POST['prodescription'];
	$donor=$_POST['donor'];
	$capital=$_POST['capital'];
	$duration=$_POST['duration'];
	$end_time=$_POST['end_time'];
	$address=$_POST['address'];
	

	$sql="UPDATE mrcbproject set  protitle=(:projecttitle), prodescription=(:prodescription),donor=(:donor),amount=(:capital),produration=(:duration), end=(:end_time),adress=(:address) where id=(:idedit)";
	$query = $dbh->prepare($sql);
	$query-> bindParam(':idedit', $idedit, PDO::PARAM_STR);
	$query-> bindParam(':projecttitle', $projecttitle, PDO::PARAM_STR);
	$query-> bindParam(':prodescription', $prodescription, PDO::PARAM_STR);
	$query-> bindParam(':donor', $donor, PDO::PARAM_STR);
	$query-> bindParam(':capital', $capital, PDO::PARAM_STR);
	$query-> bindParam(':duration', $duration, PDO::PARAM_STR);
	$query-> bindParam(':end_time',$end_time, PDO::PARAM_STR);
	$query-> bindParam(':address', $address, PDO::PARAM_STR);
	
	$query->execute();
	$msg="Information Updated Successfully";
	
}    
?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>Edit User</title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">

	<script type= "text/javascript" src="../vendor/countries.js"></script>
	<style>
.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
	background: #dd3d36;
	color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
	background: #5cb85c;
	color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.error{
	color:red;
}
		</style>
</head>

<body>
<?php
		$sql = "SELECT * from mrcbproject where id = :editid";
		$query = $dbh -> prepare($sql);
		$query->bindParam(':editid',$editid,PDO::PARAM_INT);
		$query->execute();
		$result=$query->fetch(PDO::FETCH_OBJ);
		$cnt=1;	
?>
	<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<h3 class="page-title">EDIT  MRCB PROJECT  : <?php echo htmlentities($result->prodescription)?>
						</h3>
						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-primary">
									<div class="panel-heading">EDIT MRCB PROJECT INFORMATION
									<div class="text-right">				
  <a href="mrcb_project.php" class="text-success mb-2" >BACK</a>
</div>
									</div>
<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap"><strong><?php echo htmlentities($result->prodescription);?>'s</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>

									<div class="panel-body">
<form method="post" class="form-horizontal" enctype="multipart/form-data" id ="newModalForm" name="imgform" >
<div class="form-group">
<label class="col-sm-2 control-label">Project title<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="projecttitle" class="form-control" required value="<?php echo htmlentities($result->protitle);?>">
</div>
<label class="col-sm-2 control-label">Project description<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="prodescription" class="form-control" required value="<?php echo htmlentities($result->prodescription);?>">
</div>
</div>
<div class="form-group">

<label class="col-sm-2 control-label">project date<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="date" name="pickDate" class="form-control input-md" placeholder="select new date and hit Search"required value="<?php echo htmlentities($result->prodate);?>">
</div>
<label class="col-sm-2 control-label">donor<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="donor" class="form-control" required value="<?php echo htmlentities($result->donor);?>">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Project capital<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="capital" class="form-control" required value="<?php echo htmlentities($result->amount);?>">
</div>
<label class="col-sm-2 control-label">duration<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="duration" class="form-control" required value="<?php echo htmlentities($result->produration);?>">
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">End_time<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="date" name="end_time" class="form-control" required value="<?php echo htmlentities($result->end);?>">
</div>

<label class="col-sm-2 control-label">Address<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="address" class="form-control"  value="<?php echo htmlentities($result->adress);?>">
</div>

</div>
<div class="form-group">
	<div class="col-sm-8 col-sm-offset-2">
		<input type="hidden" name="idedit" value="<?php echo htmlentities($result->id);?>" >
</div>
</div>

<div class="form-group">
	<div class="col-sm-8 col-sm-offset-2">
		<button class="btn btn-primary" name="submit" type="submit">Save Changes</button>
	</div>
</div>

</form>
									</div>
								</div>
							</div>
						</div>
						
					

					</div>
				</div>
				
			

			</div>
		</div>
	</div>

	<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
	<script src="js/main.js"></script>
	<script type="text/javascript">
				 $(document).ready(function () {          
					setTimeout(function() {
						$('.succWrap').slideUp("slow");
					}, 3000);
					
					$("#newModalForm").validate({
  rules: {
	projecttitle: {
	  required: true,
	  minlength: 3,
	  maxlength:40,
	},
	description: {
    required: true,
	  minlength: 3,
	  maxlength:300,
	  
	},
  donor: {
    required: true,
	  minlength: 3,
	  maxlength:40,
	  
	},
  address: {
    required: true,
	},
  start: {
    required: true,
	
	  
	},
  end: {
	  required:true,
	  
	},
  
  duration: {
	  required:true,
	  
	},
  owner: {
	  required:true,
	},
 capital: {
	  required:true, 
	},
  },
  messages: {
      projecttitle: {
        required: "project title is needed ",
        minlength: "project titlemust  be at least 3 characters long",
	     	maxinlength: "project title  must not  be greater than  100 characters long"
      },
	 description: {
        required: " description is required ",
        minlength: " description must  be at least 3 characters long",
	     	maxinlength: "description  must not  be greater than  300 characters long"
        
      },
      donor: {
        required: "Provide project  donor name  ",
        minlength: "project  donor must  be at least 3 charachers ",
	    maxinlength: "project  donor  must not  be greater than  200 characters "
        
      },
      start : {
        required: "Please select project start date",
        
        
      },
      end: {
        required: "Please select project end date ",
       
        
      },
      eduration: {
        required: "Please select project duration ",
       
        
      },
      address: {
        required: "address is required  ",
       
      },
      owner: {
        required: "project owner is required field ",
      },
	  capital: {
        required: "project capital is required  ",
      },
	  
    },
	
  
});
					});
	</script>

</body>
</html>
<?php } ?>