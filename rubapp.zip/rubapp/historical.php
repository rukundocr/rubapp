<?php 
session_start();
//error_reporting(0);
session_regenerate_id(true);
include('includes/config.php');

if(strlen($_SESSION['alogin'])==0)
	{	
	header("Location: index.php"); //
	}
	else{?>
<table border="1">
									<thead>
										<tr>
										<th>#</th>
											<th>province</th>
											<th>district</th>
											<th>sector</th>
											<th>branch</th>
											<th>phone</th>
											<th>phone1</th>
											
										
										</tr>
									</thead>

<?php 
$filename="branch_list";
 $sql = "SELECT * from branch order by branch_id DESC";
						
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{				

echo '  
<tr>  
<td>'.$cnt.'</td> 
<td>'.$province= $result->province.'</td> 
<td>'.$district= $result->district.'</td> 
<td>'.$sector= $result->sector.'</td> 
<td>'.$branch= $result->branch.'</td> 
<td>'.$phone= $result->phone.'</td> 
<td>'.$phone1= $result->phone1.'</td> 					
</tr>  
';
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=".$filename."-report.xls");
header("Pragma: no-cache");
header("Expires: 0");
			$cnt++;
			}
	}
?>
</table>
<?php } ?>