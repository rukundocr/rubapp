<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:login.php');
}
else{

if(isset($_GET['edit']))
	{
		$editid=$_GET['edit'];
	}


	
if(isset($_POST['submit']))
  {
	$idedit=$_POST['idedit'];
	$province=$_POST['province'];
    $district=$_POST['district'];
	$sector=$_POST['sector'];
    $phone=$_POST['phone'];
    $phone1=$_POST['phone1'];
    $branch=$_POST['branch'];
	

	$sql="UPDATE branch SET  province=(:province),district=(:district),sector=(:sector),branch=(:branch),phone=(:phone),phone1=(:phone1) WHERE branch_id=(:idedit)";
	$query = $dbh->prepare($sql);
	$query-> bindParam(':idedit', $idedit, PDO::PARAM_STR);
	$query-> bindParam(':province', $province, PDO::PARAM_STR);
	$query-> bindParam(':district', $district, PDO::PARAM_STR);
	$query-> bindParam(':sector', $sector, PDO::PARAM_STR);
	$query-> bindParam(':branch', $branch, PDO::PARAM_STR);
	$query-> bindParam(':phone', $phone, PDO::PARAM_STR);
	$query-> bindParam(':phone1', $phone1, PDO::PARAM_STR);
	$query->execute();
	$msg=" Branch info Information Updated Successfully";
	
}    
?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>Edit User</title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">

	<script type= "text/javascript" src="../vendor/countries.js"></script>
	<style>
.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
	background: #dd3d36;
	color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
	background: #5cb85c;
	color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.error{
	color:red;
}
		</style>
</head>

<body>
<?php
		$sql = "SELECT * from branch where branch_id = :editid";
		$query = $dbh -> prepare($sql);
		$query->bindParam(':editid',$editid,PDO::PARAM_INT);
		$query->execute();
		$result=$query->fetch(PDO::FETCH_OBJ);
		$cnt=1;	
?>
	<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
					<h5 class="btn btn-danger text-right">THIS IS VERY SENSITIVE INFORMATION  !! EDIT CAREFULLY TO AVOID DATA ERRORS   
					<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
					<i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
					 <i class="fa fa-exclamation-triangle" aria-hidden="true"></i></h5>
						<h5 class="page-title">Edit BRANCH   : <?php echo htmlentities($result->branch) ;?>
						</h5>
						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-primary">
									<div class="panel-heading">EDIT BRANCH
									<div class="text-right">				
  <a href="branch.php" class="text-success mb-2" >BACK</a>
</div>
									</div>
<?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap"><strong><?php echo htmlentities($result->branch);?>'s</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>

									<div class="panel-body">


<form method="post" class="form-horizontal" enctype="multipart/form-data" id ="newModalForm" name="imgform" >
<div class="form-group">
<label class="col-sm-2 control-label">Province<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="province" class="form-control" required value="<?php echo htmlentities($result->province);?>">
</div>

</div>
<div class="form-group">
<label class="col-sm-2 control-label">District<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="district" class="form-control" required value="<?php echo htmlentities($result->district);?>">
</div>

</div>
<div class="form-group">
<label class="col-sm-2 control-label">sector<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="sector" class="form-control" required value="<?php echo htmlentities($result->sector);?>">
</div>

</div>
<div class="form-group">
<label class="col-sm-2 control-label">BRANCH NAME<span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="text" name="branch" class="form-control"  required value="<?php echo htmlentities($result->branch);?>">
</div>

</div>
<div class="form-group">
<label class="col-sm-2 control-label">PHONE <span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="number" name="phone" class="form-control" required value="<?php echo htmlentities($result->phone);?>">
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">ALTERNATIVE PHONE <span style="color:red">*</span></label>
<div class="col-sm-4">
<input type="number" name="phone1" class="form-control"  value="<?php echo htmlentities($result->phone1);?>">
</div>
</div>
<div class="form-group">
	<div class="col-sm-8 col-sm-offset-2">
		<input type="hidden" name="idedit" value="<?php echo htmlentities($result->branch_id);?>" >
</div>
</div>

<div class="form-group">
	<div class="col-sm-8 col-sm-offset-2">
		<button class="btn btn-primary" name="submit" type="submit">Save Changes</button>
	</div>
</div>

</form>


									</div>
								</div>
							</div>
						</div>
						
					

					</div>
				</div>
				
			

			</div>
		</div>
	</div>

	<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
	<script src="js/chartData.js"></script>
	<script src="js/main.js"></script>
	<script type="text/javascript">
				 $(document).ready(function () {          
					setTimeout(function() {
						$('.succWrap').slideUp("slow");
					}, 3000);
					$("#newModalForm").validate({
  rules: {
	province: {
	  required: true,
	 
	},
	district: {
    required: true,
	  
	  
	},
 sector: {
    required: true,
	 
	  
	},
  branch: {
    required: true,
	  
	  
	},
  phone: {
    required: true,
	 
	  
	},
  phone1: {
	  required:false,
	  
	},
  
  },
  messages: {
      province: {
        required: "Please province ",
    
      },
	 district: {
        required: "Please enter district name ",
     
        
      },
      sector: {
        required: "Please entersector name ",
        
        
      },
      phone: {
        required: "Please enter phone Number ",
        minlength: "phone number must  be at least 10 numbers long",
	    maxinlength: "Phone numbers  must not  be greater than  10 numbers long"
        
      }
    },
	
  
});
					});
	</script>

</body>
</html>
<?php } ?>