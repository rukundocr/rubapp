<html>
<header></header>
<title></title>
<body>
<select>
<?php
include('includes/config.php');
$sql = "SELECT branch from branch";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{
    ?>
    <option><?php echo htmlentities($result->branch);?></option>
    <?php
}};
	?>
    </select>
    </body>
    <html>