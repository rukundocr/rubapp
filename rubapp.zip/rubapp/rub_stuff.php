<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
if(isset($_GET['del']))
{
$id=$_GET['del'];

$sql = "delete from staff WHERE id=:id";
$query = $dbh->prepare($sql);
$query -> bindParam(':id',$id, PDO::PARAM_STR);
$query -> execute();

$msg="Data Deleted successfully";
}

if(isset($_REQUEST['unconfirm']))
	{
	$aeid=intval($_GET['unconfirm']);
	$memstatus=1;
	$sql = "UPDATE users SET status=:status WHERE  id=:aeid";
	$query = $dbh->prepare($sql);
	$query -> bindParam(':status',$memstatus, PDO::PARAM_STR);
	$query-> bindParam(':aeid',$aeid, PDO::PARAM_STR);
	$query -> execute();
	$msg="Changes Sucessfully";
	}

	if(isset($_REQUEST['confirm']))
	{
	$aeid=intval($_GET['confirm']);
	$memstatus=0;
	$sql = "UPDATE users SET status=:status WHERE  id=:aeid";
	$query = $dbh->prepare($sql);
	$query -> bindParam(':status',$memstatus, PDO::PARAM_STR);
	$query-> bindParam(':aeid',$aeid, PDO::PARAM_STR);
	$query -> execute();
	$msg="Changes Sucessfully";
	}

	if(isset($_POST['submit'])){
		$firstname=$_POST['firstname'];
		$lastname=$_POST['lastname'];
		$nid=$_POST['nid'];
		$education=$_POST['education'];
		$hiredate=$_POST['hiredate'];
		$gender =$_POST['gender'];
		$status=$_POST['status'];
		$phone=$_POST['phone'];
		$birthdate=$_POST['birthdate'];
		$rssbnumber=$_POST['rssbnumber'];
		$whour=$_POST['whour'];
		$salary=$_POST['salary'];
		$position=$_POST['position'];
		$email=$_POST['email'];
		$residence=$_POST['residence'];
		$insurance=$_POST['insurance'];
		
$sql = " SELECT * from staff where email = '$email' ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
	$error = "user with  email: $email already exist. try another one ";
} 
$sql2 = " SELECT * from staff where NID = '$nid' ";
$query = $dbh -> prepare($sql2);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
	$error = "user with  NID: $nid already exist. try another one ";
}
else{
	
	  
	$sql="INSERT INTO staff (firstname,lastname,gender,m_status,bdate,NID,hiredate,rssbnumber,Whour,salary,education,insurance,position,residence,email,phone) 
	  VALUES (:firstname,:lastname,:gender,:status,:birthdate,:nid,:hiredate,:rssbnumber,:whour,:salary,:education,:insurance,:position,:residence,:email,:phone)";
	  $insert_QUERY = $dbh->prepare($sql);
	  $insert_QUERY->bindParam(':firstname', $firstname,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':lastname', $lastname,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':gender', $gender,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':status', $status,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':birthdate', $birthdate,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':nid', $nid,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':hiredate', $hiredate,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':rssbnumber', $rssbnumber,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':whour', $whour,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':salary', $salary,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':education', $education,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':insurance', $insurance,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':position', $position,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':residence', $residence,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':email', $email,PDO::PARAM_STR);
	  $insert_QUERY->bindParam(':phone', $phone,PDO::PARAM_STR);
	  $insert_QUERY->execute(); 
	  $msg = "staff member $firstname added well";
}
	}

 ?>

<!doctype html>
<html lang="en" class="no-js">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<meta name="theme-color" content="#3e454c">
	
	<title>RUB staff</title>

	<!-- Font awesome -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">
  <style>

	.errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
	background: #dd3d36;
	color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
	background: #5cb85c;
	color:#fff;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.error{
	color:red;
}
.required{
	color:red;
}

</style>

</head>

<body>
<div class="modal fade" id="modalRegisterForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-center">
        <h3 class="modal-title w-100 font-weight-bold text-primary">ADD STUFF</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
<h5 class="text-default">Fileds with <span class="required">*</span>are mandatory</h5>
 <form method="post" class="form-horizontal" enctype="multipart/form-data" name="imgform" id="newModalForm" onSubmit ="return valid();">
<div class="form-group">
<label class="col-sm-2 control-label">First name<span class="required">*</span></label>
<div class="col-sm-4">
<input type="text" name="firstname" placeholder ="First name" class="form-control">
</div>
<label class="col-sm-2 control-label">Last name<span class="required">*</span></label>
<div class="col-sm-4">
<input type="text" name="lastname"  placeholder ="last name" class="form-control" >
</div>
</div>
<div class="form-group">

<label class="col-sm-2 control-label">Gender<span class="required">*</span></label>
<div class="col-sm-4">
<select name="gender"  class="form-control" >
                            <option selected disabled >select  your gender</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            </select>
</div>
<label class="col-sm-2 control-label">Marital Status<span style="color:red">*</span></label>
<div class="col-sm-4">
<select name="status"  class="form-control" >
                            <option selected disabled >select  Marital Status<span class="required">*</span></option>
                            <option value="single">single</option>
  <option value="married">married</option>
  <option value="divorced">Divorced</option>
  <option value="widowed">Widowed</option>
                            </select>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Nid<span class="required">*</span></label>
<div class="col-sm-4">
<input type="number" name="nid" placeholder ="Enter NID" class="form-control" >
</div>
<label class="col-sm-2 control-label">Rssb number<span class="required">*</span></label>
<div class="col-sm-4">
<input type="text" name="rssbnumber" placeholder ="Enter RSSB number" class="form-control"  >
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Birth_date<span class="required">*</span></label>
<div class="col-sm-4">
<input type="date" name="birthdate" placeholder ="select date" class="form-control" >
</div>

<label class="col-sm-2 control-label">Insurence<span class="required">*</span></label>
<div class="col-sm-4">
<input type="text" name="insurance" placeholder ="Enter Insurance number" class="form-control"  >
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Hired_date<span class="required">*</span></label>
<div class="col-sm-4">
<input type="date" name="hiredate" placeholder ="select hired date" class="form-control" >
</div>

<label class="col-sm-2 control-label">Phone<span class="required">*</span></label>
<div class="col-sm-4">
<input type="number" name="phone" placeholder ="Enter phone numbers" class="form-control"  >
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Work Hours<span class="required">*</span></label>
<div class="col-sm-4">
<input type="number" name="whour" placeholder =" Work hours" class="form-control" >
</div>

<label class="col-sm-2 control-label">salary<span class="required">*</span></label>
<div class="col-sm-4">
<input type="text" name="salary" placeholder ="Enter salary"  class="form-control"  >
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Education<span class="required">*</span></label>
<div class="col-sm-4">
<select name="education" class="form-control"  >
                            <option selected disabled >select to change your education </option>
                            <option value="secondary">A2 Certificate</option>
                            <option value="University">bachelors degree</option>
                            <option value="Masters">Masters</option>
                            <option value="phd">Phd</option>
                            <option value="none">None</option>
                            </select>

</div>

<label class="col-sm-2 control-label">Position<span class="required">*</span></label>
<div class="col-sm-4">
<input type="text" name="position" placeholder ="Position" class="form-control"  >
</div>
</div>
<div class="form-group">
<label class="col-sm-2 control-label">Residence <span class="required">*</span></label>
<div class="col-sm-4">
<input type="text" name="residence" placeholder ="Residence" class="form-control"  >
</div>

<label class="col-sm-2 control-label">Email<span class="required">*</span></label>
<div class="col-sm-4">
<input type="email" name="email" placeholder ="Enter Email" class="form-control" >
</div>
</div>

<div class="form-group">
	<div class="col-sm-8 col-sm-offset-2">
		<input type="hidden" name="idedit"  >
</div>
</div>
      <div class="modal-footer d-flex justify-content-center">
        <button type="submit" name="submit" class="btn btn-primary">SAVE</button>
		<button type="button" class="btn btn-danger" id="btnCloseIt" data-dismiss="modal">Close</button>
      </div>
	 
    </div>
	</form>
  </div>
</div>



	<?php include('includes/header.php');?>

	<div class="ts-main-content">
		<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-12">

						<!-- Zero Configuration Table -->
						<div class="panel panel-primary">
							<div class="panel-heading text-center"><h5>RUB STUFF</h5>
							<div class="text-right">
  <a href="" class="text-success " data-toggle="modal" data-target="#modalRegisterForm">Add Stuff Member</a>
</div>
							</div>
	
							<div class="panel-body">
							<?php if($error){?><div class="errorWrap" id="msgshow"><?php echo htmlentities($error); ?> </div><?php } 
				else if($msg){?><div class="succWrap" id="msgshow"><?php echo htmlentities($msg); ?> </div><?php }?>
								<div class="table-responsive table-bordered">
								<table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
									<thead>
										<tr>
										<th>#</th>
											
                                                <th>First name</th>
                                                <th>Last name</th>
                                                <th>Gender</th>
											    <th>Phone number</th>
												<th>NationID</th>
												<th>Education</th>
												<th>Position</th>
												<th>RESIDENCE</th>
												<th>Marital Status</th>
                                                <th>Birth date</th>
                                                <th>HIRED DATE</th>
											    <th>RSSB NUMBER</th>
												<th>INSURANCE NUMBER</th>
												<th>WORK HOURS</th>
												<th>SALARY</th>
												<th>RESIDENCE</th>
												<th>EMAIL</th>
												

                                            
											<th>Action</th>	
										</tr>
									</thead>
									
									<tbody>

<?php $sql = "SELECT * from staff ";
$query = $dbh -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $result)
{				?>	
<tr>
<td><?php echo htmlentities($cnt);?></td>
<td><?php echo htmlentities($result->firstname);?></td>
<td><?php echo htmlentities($result->lastname);?></td>
<td><?php echo htmlentities($result->gender);?></td>
<td><?php echo htmlentities($result->phone);?></td>
<td><?php echo htmlentities($result->NID);?></td>
<td><?php echo htmlentities($result->education);?></td>
<td><?php echo htmlentities($result->position);?></td>
<td><?php echo htmlentities($result->residence);?></td>
<td><?php echo htmlentities($result->m_status);?></td>
<td><?php echo htmlentities($result->bdate);?></td>
<td><?php echo htmlentities($result->hiredate);?></td>
<td><?php echo htmlentities($result->rssbnumber);?></td>
<td><?php echo htmlentities($result->insurance);?></td>
<td><?php echo htmlentities($result->whour);?></td>
<td><?php echo htmlentities($result->salary);?></td>
<td><?php echo htmlentities($result->residence);?></td>
<td><?php echo htmlentities($result->email);?></td>
											
<td>
<a href="edit_rub_stuff.php?edit=<?php echo $result->id;?>" onclick="return confirm('Do you want to Edit');">&nbsp; <i class="fa fa-pencil"></i></a>&nbsp;&nbsp;
<a href="rub_stuff.php?del=<?php echo $result->id;?>" onclick="return confirm('Do you want to Delete');"><i class="fa fa-trash" style="color:red"></i></a>&nbsp;&nbsp;
</td>
										</tr>
										<?php $cnt=$cnt+1; }} ?>
										
									</tbody>
								</table>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>

	<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	<script src="js/chartData.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
	<script src="js/main.js"></script>
	<script type="text/javascript">
				 $(document).ready(function () {          
					setTimeout(function() {
						$('.succWrap').slideUp("slow");
					}, 3000);
					setTimeout(function() {
						$('.errorWrap').slideUp("slow");
					}, 5000);
					$("#newModalForm").validate({
  rules: {
	fname: {
	  required: true,
	  minlength: 3,
	  maxlength:40,
	},
	lname: {
    required: true,
	  minlength: 3,
	  maxlength:40,
	  
	},
  nid: {
    required: true,
	  minlength: 16,
	  maxlength:16,
	  
	},
  phone: {
    required: true,
	  minlength: 10,
	  maxlength:10,
	  
	},
  rssbnumber: {
    required: true,
	minlength: 9,
	  maxlength:9, 
	  
	},
  education: {
	  required:true,
	  
	},
  gender: {
	  required:true,
	  
	},
  status: {
	  required:true,
	  
	},
  email: {
	  required:true,
	},
  insurance: {
	  required:true,
	  minlength: 9,
	  maxlength:9, 
	},
  whour: {
	  required:true,
	 
	},
  residence: {
	  required:true,
	},
	position: {
	  required:true,
	},
	salary: {
	  required:true,
	},
	hired: {
	  required:true,
	},
	birthdate: {
	  required:true,
	},
  },
  messages: {
      fname: {
        required: "Please enter First Name ",
        minlength: "Lastname must  be at least 3 characters long",
	     	maxinlength: "Your Last  must not  be greater than  40 characters long"
      },
	 lname: {
        required: "Please enter last name ",
        minlength: "Lastname must  be at least 3 characters long",
	     	maxinlength: "Your Last  must not  be greater than  40 characters long"
        
      },
      nid: {
        required: "Please enter the  ID ",
        minlength: "NID number must  be at least 16 numbers",
	     	maxinlength: "NID number  must not  be greater than  16 numbers long"
        
      },
      phone: {
        required: "Please enter phone Number ",
        minlength: "phone number must  be at least 10 numbers long",
	     	maxinlength: "Phone numbers  must not  be greater than  10 numbers long"
        
      },
      ubudehe: {
        required: "Please select UBUDEHE Cathegory ",
       
        
      },
      education: {
        required: "Please select Education Level ",
       
        
      },
      gender: {
        required: "Please select Gender ",
       
      },
      status: {
        required: "Please select martital Status ",
      },
	  rssbnumber: {
        required: "Please enter rssb number ",
		minlength: "minimum 9 digits ",
	    maxinlength: "maximum is 9 digit ",

      },
      email: {
        required: "Please enter email",
      },
      whour: {
        required: "Please provide work hours",
		
      },
      position: {
        required: "Please provide position",
      },
      residence: {
        required: "Please provide residence",
      },
	  residence: {
        required: "Please provide salary",
      },
	  hired: {
        required: "Please provide hired date",
      },
	  birthdate: {
        required: "Please provide birth date ",
      },
    },
	
  
});





					});
					
		</script>
		
</body>
</html>
<?php } ?>
