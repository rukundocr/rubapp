<?php
namespace Phppot;
use Phppot\CountryState;
require_once __DIR__ . '/Model/CountryStateCity.php';
include("connect.php");

$countryStateCity = new CountryStateCity();
$countryResult = $countryStateCity->getAllCountry();
$branchResults = $countryStateCity->getAllbranch();

if(isset($_GET['edit']))
	{
		$editid=$_GET['edit'];
	}


if(isset($_POST['submit'])){
    $province=$_POST['country'];
    $district=$_POST['state'];
    $sector=$_POST['city'];
    $firstname=$_POST['fname'];
    $lastname=$_POST['lname'];
    $nid=$_POST['nid'];
    $ubudehe=$_POST['ubudehe'];
    $edu_level=$_POST['edu_level'];
    $vstatus=$_POST['vstatus'];
    $gender =$_POST['gender'];
    $cause=$_POST['cause'];
    $branch=$_POST['branch'];
    $status=$_POST['status'];
    $phone=$_POST['phone'];
    $branch=$_POST['branch'];
    $year_sight_loss =$_POST['year'];
    $other=$_POST['other'];
    $birthdate=$_POST['birth'];
    $occupation=$_POST['occupation'];
      
    $sql1="SELECT province_name FROM province where id=$province";
    $run_query1=mysqli_query($conn,$sql1);
    while($res1 = mysqli_fetch_array($run_query1))
    {
    $result1=  $res1['province_name'];
    $sql2="SELECT district_name FROM districts where id=$district";
    $run_quer=mysqli_query($conn,$sql2);
    while($result = mysqli_fetch_array($run_quer))
    {
    $result2=  $result['district_name'];
    $sql3="SELECT sector_name FROM sectors where id=$sector";
    $run_querls=mysqli_query($conn,$sql3);
    while($results= mysqli_fetch_array($run_querls))
    {
    $resultlsector= $results['sector_name'];
    $sql4="SELECT branch FROM branch where branch_id=$branch"; 
    $run_query4=mysqli_query($conn,$sql4);
    while($re= mysqli_fetch_array($run_query4))
    {
    $branchname= $re['branch'];
    $sql2="INSERT INTO members (province,district,sector,branch,firstname,lastname,gender,birthdate,
    m_status,nid,phone,year_sight_loss,occupation,edu_level,visual_status,cuase_visual,other_disab,ubudehe) 
    VALUES('$result1',' $result2','$resultlsector','$branchname','$firstname','$lastname','$gender','$birthdate',
    '$status','$nid','$phone','$year_sight_loss','$occupation','$edu_level','$vstatus','$cause','$other','$ubudehe')";
    $run_query2=mysqli_query($conn,$sql2);
    $msg = "Member  $firstname $lastname is added successfullly";
    }
  }
  }
}
}
?>
<html>
<head>
<TITLE>select</TITLE>
<head>
<link href="./assets/css/style.css" rel="stylesheet" type="text/css" />
<script src="./vendor/jquery/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="./assets/js/ajax-handler.js" type="text/javascript"></script>



<!-- Font awesome -->
<link rel="stylesheet" href="css/font-awesome.min.css">
	<!-- Sandstone Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!-- Bootstrap Datatables -->
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<!-- Bootstrap social button library -->
	<link rel="stylesheet" href="css/bootstrap-social.css">
	<!-- Bootstrap select -->
	<link rel="stylesheet" href="css/bootstrap-select.css">
	<!-- Bootstrap file input -->
	<link rel="stylesheet" href="css/fileinput.min.css">
	<!-- Awesome Bootstrap checkbox -->
	<link rel="stylesheet" href="css/awesome-bootstrap-checkbox.css">
	<!-- Admin Stye -->
	<link rel="stylesheet" href="css/style.css">

	<script type= "text/javascript" src="../vendor/countries.js"></script>
</head>
<style>
.required{
  color:red;
}
.error{
  color:red;
}

</style>
<body>

<?php
//getting id from url

$sql= "SELECT * FROM memebrs WHERE member_id='$editid'";
$result = mysqli_query($conn,$sql);
 if ($result){
       $res=mysqli_fetch_array($result);
    
        $id = $res['member_id'];
        $firstname = $res['firstname'];
        $lastname= $res['lastname'];
        $gender = $res['gender'];
        $status = $res['m_status'];
        $NID= $res['nid'];
        $datebirth= $res['birthdate'];
        $year= $res['year_sight_loss'];
        $vstatus= $res['visual_status'];
        $cause = $res['cuase_visual'];
        $other= $res['other_disab'];	
        $edulevel =$res['edu_level'];
        $branch= $res['branch'];
        $ubudehe= $res['ubudehe'];
        $phone = $res['phone'];
        $district = $res['district'];
        $province = $res['province'];
        $sector = $res['sector'];
    
    
 }

?>
<?php include('includes/header.php');?>
	<div class="ts-main-content">
	<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<h3 class="page-title">Edit member : </h3>
						<div class="row">
							<div class="col-md-12">
								<div class="panel panel-primary">
									<div class="panel-heading">Edit member information
									<div class="text-right">				
  <a href="userlist.php" class="text-success mb-2" >BACK</a>
</div>
									</div>


<div class="modal fade" id="modalRegisterForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-center">
        <h3 class="modal-title w-100 font-weight-bold text-primary"> UPDATE MEMBER INFO</h3>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <h5 class="text-default">Fields with <span class="required">*</span> are mandatory</h5>
	  <form method="post" class="form-horizontal" enctype="multipart/form-data" name="imgform" role="form" id="newModalForm" onSubmit ="return valid();" >
      <div class="modal-body mx-8">
        <div class="md-form mb-2">
		      <label  class="text-primary" for="orangeForm-name">First Name<span class="required">*</span></label>
          <input type="text" id="orangeForm-name" name = "fname" placeholder="Enter First Name" class="form-control validate" value="<?php echo htmlentities($firstname);?>">
         
        </div>
        <div class="md-form mb-2">
		<label class="text-primary" for="orangeForm-email">Last Name<span class="required">*</span></label>
          <input type="text" id="orangeForm-email"  name = "lname" placeholder="Enter Last Name" class="form-control validate"value="<?php echo htmlentities($lastname);?>">
          
        </div>

        <div class="md-form mb-2">
        <label  class="text-primary" for="orangeForm-pass">NID<span class="required">*</span></label>
          <input type="number" id="orangeForm-pass"  name = "nid" placeholder="NATIONAL ID" class="form-control validate" value="<?php echo htmlentities($nid);?>">
          
        </div>
        <div class="md-form mb-2">
        <label  class="text-primary" for="orangeForm-pass">PHONE</label>
          <input type="number" id="orangeForm-pass"  name = "phone" placeholder="Phone Number" class="form-control validate " value="<?php echo htmlentities($phone);?>">
          
        </div>
        <div class="md-form mb-2">
        <label  class="text-primary" for="orangeForm-pass">IKICIRO CY'UBUDEHE</label>
		<select class="form-control validate" name="ubudehe">
   <option value="<?php echo htmlentities($ubudehe);?>"><?php echo htmlentities($ubudehe);?></option>
    <option value="A">A</option>
    <option value="B">B</option>
    <option value="C">C</option>
    <option value="D">D</option>
    <option value="E">E</option>
           </select>
          
        </div>
        <div class="md-form mb-2">
        <label  class="text-primary" for="orangeForm-pass">Education Level</label>
		<select class="form-control validate" name="edu_level">
   <option value="<?php echo htmlentities($ubudehe);?>"><?php echo htmlentities($ubudehe);?></option>
    <option value="No formal education">No formal education</option>
    <option value="Primary education">Primary education</option>
    <option value="Secondary education">Secondary education or high school</option>
    <option value="Vocational qualification">Vocational qualification</option>
    <option value="Bachelor's degree">Bachelor's degree</option>
    <option value="Master's degree">Master's degree</option>
    <option value="Doctorate or higher">Doctorate or higher</option>
           </select>
          
        </div>

		<div class="md-form mb-2">
		<label class="text-primary" for="orangeForm-email">Visual Status</label>
          <input type="text" id="orangeForm-email"  name = "vstatus" placeholder="Visual Status" class="form-control validate" value="<?php echo htmlentities($vstatus);?>">
          
        </div>
        <div class="md-form mb-2">
        <label  class="text-primary" for="orangeForm-pass">BIRTH DATE </label>
          <input type="date" id="orangeForm-pass"  name = "birth" placeholder="BIRTH DATE" class="form-control validate" value="<?php echo htmlentities($datebirth);?>">
          
        </div>

        <div class="md-form mb-2">
        <label  class="text-primary" for="orangeForm-pass">Cause of Sight Loss</label>
          <input type="text" id="orangeForm-pass"  name = "cause" placeholder="Cause of Sight Loss" class="form-control validate" value="<?php echo htmlentities($cause);?>">
          
        </div>
        <div class="md-form mb-2">
        <label  class="text-primary" for="orangeForm-pass">Year of Sight Loss</label>
          <input type="text" id="orangeForm-pass"  name = "year" placeholder="Yaar of Sight Loss" class="form-control validate" value="<?php echo htmlentities($year);?>">
          
        </div>
        <div class="md-form mb-2">
        <label  class="text-primary" for="orangeForm-pass">Occupation</label>
          <input type="text" id="orangeForm-pass"  name = "occupation" placeholder="Occupation" class="form-control validate" value="<?php echo htmlentities($occupation);?>">
          
        </div>
		<div class="md-form mb-2">
        <label  class="text-primary" for="orangeForm-pass">Other Disability</label>
          <input type="text" id="orangeForm-pass"  name = "other" placeholder="Other Disability" class="form-control validate" value="<?php echo htmlentities($other);?>">
          
        </div>

		<div class="md-form mb-2">
		<label  class="text-primary" for="orangeForm-pass">Gender<span class="required">*</span></label>
		<select class="form-control validate" name ="gender">
  <option  value="<?php echo htmlentities($gender);?>"><?php echo htmlentities($gender);?> </option>
  <option value="male">MALE</option>
  <option value="female">FEMALE</option>
 
</select>
          
        </div>
        <div class="md-form mb-2">
		<label  class="text-primary" for="orangeForm-pass">Marital Status<span class="required">*</span></label>
		<select class="form-control validate" name ="status">
  <option  value="<?php echo htmlentities($staus);?>"><?php echo htmlentities($status);?> </option>
  <option value="single">single</option>
  <option value="married">married</option>
  <option value="divorced">Divorced</option>
  <option value="widowed">Widowed</option>
 
</select>
        </div>

        <div class="md-form mb-2">
        <label  class="text-primary" for="orangeForm-pass">branch<span class="required">*</span></label>
        <select  id="branch" name="branch" class="form-control validate">
		                    	<option  value="<?php echo htmlentities($branch);?>"><?php echo htmlentities($branch);?></option>
                          <?php
foreach ($branchResults as $branch) {
    ?>
<option value="<?php echo $branch["branch_id"]; ?>"><?php echo $branch["branch"]; ?></option>
<?php
}
?>


		                    </select>
          
        </div>
		<div class="md-form mb-2">
    <label  class="text-primary" for="orangeForm-pass">Province<span class="required">*</span></label>
		<select name="country"
                id="country-list" 
				        class="form-control validate"
                onChange="getState(this.value);">
        <option  value="<?php echo htmlentities($province);?>"><?php echo htmlentities($province);?></option>
<?php
foreach ($countryResult as $country) {
    ?>
<option value="<?php echo $country["id"]; ?>"><?php echo $country["province_name"]; ?></option>
<?php
}
?>
</select>
          
        </div>
		<div class="md-form mb-2">
        <label  class="text-primary" for="orangeForm-pass">District<span class="required">*</span></label>
		<select name="state"  required
id="state-list" class="form-control validate"
onChange="getCity(this.value);">
<option  value="<?php echo htmlentities($district);?>"><?php echo htmlentities($district);?></option>
</select>
        </div>
		<div class="md-form mb-2">
        <label  class="text-primary" for="orangeForm-pass">Sector<span class="required">*</span></label>
		<select name="city" 
		        
                id="city-list" class="form-control validate">
                <option  value="<?php echo htmlentities($ubudehe);?>"><?php echo htmlentities($ubudehe);?></option>
            </select>
</select>
          
        </div>

      </div>
      <div class="modal-footer d-flex justify-content-center">
        <button type="submit" name="submit" class="btn btn-primary">SAVE</button>
		<button type="button" class="btn btn-danger" id="btnCloseIt" data-dismiss="modal">Close</button>
      </div>
    </div>
	</form>
  </div>
</div>

	<!-- Loading Scripts -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap-select.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.min.js"></script>
	<script src="js/Chart.min.js"></script>
	<script src="js/fileinput.js"></script>
	
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.js"></script>
<script type="text/javascript">
				 $(document).ready(function () {          
					setTimeout(function() {
						$('.succWrap').slideUp("slow");
					}, 3000);
					setTimeout(function() {
						$('.errorWrap').slideUp("slow");
					}, 5000);

					



					});
          </script>
</body>
</html>