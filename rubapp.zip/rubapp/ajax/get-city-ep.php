<?php
namespace Phppot;

use Phppot\CountryState;
if (!empty($_POST["district_id"])) {
    
    $districtid = $_POST["district_id"];
    
    require_once __DIR__ . '/../Model/CountryStateCity.php';
    $countryStateCity = new CountryStateCity();
    $cityResult = $countryStateCity->getSectorByDistrictid($districtid);
    ?>
<option>Select sector</option>
<?php
foreach ($cityResult as $city) {
        ?>
<option value="<?php echo $city["id"]; ?>"><?php echo $city["sector_name"]; ?></option>
<?php
    }
}
?>