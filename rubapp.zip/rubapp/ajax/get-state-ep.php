<?php
namespace Phppot;

use Phppot\CountryState;
if (! empty($_POST["province_id"])) {
    
    $provinceId = $_POST["province_id"];
    
    require_once __DIR__ . '/../Model/CountryStateCity.php';
    $countryStateCity = new CountryStateCity();
    $stateResult = $countryStateCity->getStateByCountrId($provinceId);
    ?>
<option value="">Select district</option>
<?php
    foreach ($stateResult as $state) {
        ?>

<option value="<?php echo $state["id"];?>"><?php echo $state["district_name"]; ?></option>
<?php
    }
}
?>