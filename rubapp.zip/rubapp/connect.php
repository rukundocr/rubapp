<?php
$username = "root";
$password = "";
$host = "localhost";
$conn =mysqli_connect($host,$username,$password);
$selectdb = mysqli_select_db($conn,'rubura_srd');

if($conn){
	echo("");
}else{
	echo("could not connect to database".mysqli_error());
}

?>
