<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" 
	integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" 
	crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.5.1.js" 
	integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc="
	 crossorigin="anonymous"></script>
	
</head>
<body>

	<div class="container">
	  <div class="row">
                <div class="col-s12-md4">
                     <form method="post" action="data.php">
				          <label for="authors">Authors</label>
		                    <select  id="province" name="province">
		                    	<option selected="" disabled="">Select Province</option>
		                    	<?php 
		                    		require 'data.php';
		                    		$authors = loadAuthors();
		                    		foreach ($authors as $author) {
		                    			echo "<option id='".$author['id']."' value='".$author['id']."'>".$author['province_name']."</option>";
		                    		}
		                    	 ?>
		                    </select>
							<label for="books">District</label>
		                    <select  id="district" name="district">
		                    <option selected="" disabled="">Select District</option>
		                    </select>
							<label for="books">Sector</label>
		                    <select  id="sector" name="sector">
							<option selected="" disabled="">Select Sector</option>
		                    </select>

							<input type="submit" value ="submit" name="submit">
				 
				      </form>


                    </div>
			</div>
	</div>


	<script src= "main1.js"></script>
</body>
</html>